/* Proyecto educativo: simulación local; no mide ni enruta tráfico real. */
const $ = (s) => document.querySelector(s), $$ = (s) => [...document.querySelectorAll(s)];
const K = { users: 'nc_users', session: 'nc_session', settings: 'nc_settings', process: 'nc_process', logs: 'nc_logs' };
const get = (k, fallback) => { try {
    return JSON.parse(localStorage.getItem(k)) ?? fallback;
}
catch {
    return fallback;
} };
const put = (k, v) => localStorage.setItem(k, JSON.stringify(v));
const session = () => get(K.session, null), users = () => get(K.users, []);
const defaultProcess = () => ({ active: false, step: 0, started: null });
const processState = () => get(K.process, defaultProcess());
const sampleNodes = [{ name: 'Dispositivo local', ip: '192.168.1.10', ms: 1, region: 'Red local' }, { name: 'Puerta de enlace', ip: '192.168.1.1', ms: 4, region: 'Router de acceso' }, { name: 'Nodo de entrada', ip: '10.10.0.2', ms: 18, region: 'Simulado · Madrid' }, { name: 'Nodo intermedio', ip: '10.20.0.4', ms: 35, region: 'Simulado · París' }, { name: 'Nodo de salida', ip: '10.30.0.8', ms: 58, region: 'Simulado · Ámsterdam' }, { name: 'Destino de prueba', ip: '203.0.113.10', ms: 71, region: 'IP de documentación' }];
let interval;
function toast(s) { const t = $('#toast'); if (!t)
    return; t.textContent = s; t.classList.remove('hidden'); clearTimeout(window._toastT); window._toastT = setTimeout(() => t.classList.add('hidden'), 3500); }
function log(msg) { const l = get(K.logs, []); l.unshift({ time: new Date().toLocaleTimeString('es-ES'), msg }); put(K.logs, l.slice(0, 30)); }
function applySettings() { const st = get(K.settings, {}); document.body.classList.toggle('light', st.theme === 'light'); document.body.classList.toggle('purple', st.accent === 'purple'); }
function initAuth() { applySettings(); const form = $('#authForm'); if (!form)
    return; form.addEventListener('submit', (e) => { e.preventDefault(); const fd = new FormData(form), email = String(fd.get('email') || '').trim().toLowerCase(), password = String(fd.get('password') || ''); const error = $('#authError'); error.textContent = ''; if (document.body.dataset.page === 'register') {
    const name = String(fd.get('name') || '').trim();
    if (name.length < 2 || password.length < 6) {
        error.textContent = 'Escribe un nombre y una contraseña de al menos 6 caracteres.';
        return;
    }
    if (users().some(u => u.email === email)) {
        error.textContent = 'Ese correo ya está registrado.';
        return;
    }
    const account = { id: Date.now(), name, email };
    put(K.users, [...users(), { ...account, password }]);
    put(K.session, account);
    location.href = 'index.html';
}
else {
    const u = users().find(u => u.email === email && u.password === password);
    if (!u) {
        error.textContent = 'Correo o contraseña incorrectos.';
        return;
    }
    put(K.session, { id: u.id, name: u.name, email: u.email });
    location.href = 'index.html';
} }); }
function initApp() { applySettings(); if (!session()) {
    location.replace('login.html');
    return;
} const u = session(); $$('[data-name]').forEach(el => el.textContent = u.name); $$('[data-initial]').forEach(el => el.textContent = u.name.slice(0, 1).toUpperCase()); $$('[data-email]').forEach(el => el.textContent = u.email); $$('[data-page-link]').forEach(a => a.classList.toggle('active', a.dataset.pageLink === document.body.dataset.page)); $('#logout')?.addEventListener('click', () => { localStorage.removeItem(K.session); location.href = 'login.html'; }); $$('[data-logout]').forEach(x => x.addEventListener('click', () => { localStorage.removeItem(K.session); location.href = 'login.html'; })); const clock = () => { if ($('#clock'))
    $('#clock').textContent = new Date().toLocaleString('es-ES', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' }); }; clock(); setInterval(clock, 30000); $('#start')?.addEventListener('click', () => { const s = processState(); if (s.active) {
    s.active = false;
    log('Simulación pausada');
}
else {
    if (s.step >= sampleNodes.length)
        s.step = 0;
    s.active = true;
    s.started ??= Date.now();
    log('Simulación iniciada');
} put(K.process, s); render(); toast(s.active ? 'Proceso de demostración iniciado' : 'Proceso pausado'); }); $('#reset')?.addEventListener('click', () => { put(K.process, defaultProcess()); log('Simulación reiniciada'); render(); toast('Proceso reiniciado'); }); $('#clearLogs')?.addEventListener('click', () => { put(K.logs, []); render(); }); $('#saveProfile')?.addEventListener('submit', e => { e.preventDefault(); const name = $('#profileName').value.trim(); if (name.length < 2)
    return toast('Introduce un nombre válido'); const u = session(), all = users(); u.name = name; put(K.session, u); put(K.users, all.map(x => x.id === u.id ? { ...x, name } : x)); toast('Perfil guardado'); render(); }); $('#saveSettings')?.addEventListener('submit', e => { e.preventDefault(); put(K.settings, { theme: $('#theme').value, accent: $('#accent').value, notifications: $('#notifications').checked }); applySettings(); toast('Configuración guardada'); }); const st = get(K.settings, {}); if ($('#theme'))
    $('#theme').value = st.theme || 'dark'; if ($('#accent'))
    $('#accent').value = st.accent || 'blue'; if ($('#notifications'))
    $('#notifications').checked = st.notifications !== false; if ($('#profileName'))
    $('#profileName').value = u.name; if ($('#profileEmail'))
    $('#profileEmail').value = u.email; render(); interval = setInterval(() => { const s = processState(); if (!s.active)
    return; if (s.step < sampleNodes.length) {
    s.step++;
    if (s.step === sampleNodes.length) {
        s.active = false;
        log('Ruta de demostración completada');
    }
    else
        log('Salto ' + s.step + ': ' + sampleNodes[s.step - 1].name);
    put(K.process, s);
    render();
} }, 1800); }
function render() { const s = processState(), count = s.step, completed = count === sampleNodes.length; $$('[data-process-status]').forEach(el => { el.textContent = s.active ? 'En proceso' : completed ? 'Completado' : 'Detenido'; el.classList.toggle('off', !s.active && !completed); }); $$('[data-hop-count]').forEach(el => el.textContent = count + ' / ' + sampleNodes.length); $$('[data-current-node]').forEach(el => el.textContent = count ? sampleNodes[count - 1].name : 'Sin iniciar'); $$('[data-latency]').forEach(el => el.textContent = count ? sampleNodes[count - 1].ms + ' ms' : '—'); $$('[data-connection]').forEach(el => el.textContent = s.active ? 'Conectando (simulado)' : completed ? 'Ruta completada' : 'Sin proceso'); $$('[data-start-label]').forEach(el => el.textContent = s.active ? '❚❚ Pausar proceso' : completed ? '▶ Repetir proceso' : '▶ Iniciar proceso'); if ($('#nodeList'))
    $('#nodeList').innerHTML = sampleNodes.map((n, i) => `<div class="hop"><div class="hop-number">${i + 1}</div><div><strong>${n.name}</strong><small>${n.region} · ${n.ip}</small></div><div class="tiny">${i < count ? '<span class="positive">✓ ' + n.ms + ' ms</span>' : 'Pendiente'}</div></div>`).join(''); if ($('#logList')) {
    const logs = get(K.logs, []);
    $('#logList').innerHTML = logs.length ? logs.map(l => `<div class="log-item"><time>${l.time}</time>${escapeHtml(l.msg)}</div>`).join('') : '<div class="empty">Aún no hay eventos. Pulsa «Iniciar proceso».</div>';
} if ($('#topology')) {
    const coords = [[53, 136], [155, 65], [265, 136], [374, 65], [486, 136], [587, 65]];
    let content = '';
    coords.forEach(([x, y], i) => { if (i)
        content += `<line x1="${coords[i - 1][0]}" y1="${coords[i - 1][1]}" x2="${x}" y2="${y}" style="opacity:${i < count ? 1 : .22}"/>`; });
    coords.forEach(([x, y], i) => content += `<circle cx="${x}" cy="${y}" r="${i === count - 1 && count ? 14 : 11}" class="${i < count ? 'current' : ''}" style="opacity:${i < count ? 1 : .45}"/><text x="${x}" y="${y + 32}" text-anchor="middle">${['Equipo', 'Router', 'Entrada', 'Intermedio', 'Salida', 'Destino'][i]}</text>`);
    $('#topology').innerHTML = content;
} }
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
document.addEventListener('DOMContentLoaded', () => document.body.classList.contains('auth') ? initAuth() : initApp());


