NETWORK CONTROL — PROYECTO ORDENADO

1. Abre la carpeta network-control-ordenado en Visual Studio Code.
2. Si aparece «Modo restringido», selecciona «Confiar en esta carpeta» solo si has revisado su contenido.
3. Abre login.html (o register.html) en el navegador. Puedes usar la extensión Live Server de VS Code.
4. Crea una cuenta de prueba; no utilices contraseñas reales.
5. Accede a index.html y pulsa «Iniciar proceso».
6. Navega por usuario.html, red.html, nodos.html y configuracion.html.

El login es de demostración y guarda datos en localStorage. La red y los nodos están SIMULADOS; no hay conexiones ni saltos reales.

Archivos: index.html, login.html, register.html, usuario.html, red.html, nodos.html, configuracion.html, style.css, app.js.
