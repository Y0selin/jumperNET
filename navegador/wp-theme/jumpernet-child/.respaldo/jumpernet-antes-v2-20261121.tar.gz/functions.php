<?php
/*
 * JumperNET Docs — tema hijo de Twenty Twenty-Four.
 *
 * v1.2.0
 *  · Vídeo «El viaje» integrado en la portada y como intro a pantalla completa.
 *  · Fondo animado (aurora, rejilla y campo de estrellas) + microinteracciones.
 *  · Cabecera y logo renovados.
 *  · Panel propio al iniciar sesión: widget rápido, menú JumperNET, accesos
 *    en la barra de administración y login con la marca.
 */

if (!defined('JN_VERSION')) {
	define('JN_VERSION', '1.3.0');
}

/* ─── utilidades de assets ─── */
function jn_asset_uri($ruta = '') {
	return get_stylesheet_directory_uri() . '/assets/' . ltrim($ruta, '/');
}
function jn_asset_path($ruta = '') {
	return get_stylesheet_directory() . '/assets/' . ltrim($ruta, '/');
}
function jn_hay_video() {
	return file_exists(jn_asset_path('el-viaje.mp4'));
}

add_action('wp_enqueue_scripts', function () {
	if (wp_get_theme()->parent()) {
		wp_enqueue_style(
			'twentytwentyfour-style',
			get_template_directory_uri() . '/style.css',
			array(),
			wp_get_theme()->parent()->get('Version')
		);
	}
	wp_enqueue_style('jumpernet-child', get_stylesheet_uri(), array('twentytwentyfour-style'), JN_VERSION);

	wp_enqueue_script('jumpernet-sitio', jn_asset_uri('jn-sitio.js'), array(), JN_VERSION, true);
	wp_add_inline_script(
		'jumpernet-sitio',
		'window.JN = ' . wp_json_encode(array(
			'video'   => jn_hay_video() ? jn_asset_uri('el-viaje.mp4') : '',
			'portada' => is_front_page(),
		)) . ';',
		'before'
	);
});

/* ─── login con la marca ─── */
add_filter('login_headerurl', function () { return home_url('/'); });
add_filter('login_headertext', function () { return 'JumperNET'; });

add_action('login_enqueue_scripts', function () {
	?>
	<style>
		body.login{
			background:#07050b !important;
			background-image:
				radial-gradient(900px 460px at 62% -12%, rgba(255,90,54,.22), transparent 62%),
				radial-gradient(760px 420px at -4% 104%, rgba(139,123,255,.20), transparent 64%),
				linear-gradient(rgba(255,255,255,.025) 1px, transparent 1px),
				linear-gradient(90deg, rgba(255,255,255,.025) 1px, transparent 1px) !important;
			background-size:auto,auto,48px 48px,48px 48px !important;
		}
		#login h1{display:none}
		#login::before{
			content:"↯  JumperNET";
			display:block;text-align:center;
			font-family:ui-monospace,Consolas,monospace;font-weight:800;
			font-size:24px;letter-spacing:.01em;margin-bottom:20px;
			background:linear-gradient(100deg,#ffd0c0,#ff7a55 42%,#b3a4ff);
			-webkit-background-clip:text;background-clip:text;color:transparent;
			filter:drop-shadow(0 10px 26px rgba(255,90,54,.35));
		}
		#loginform::before{
			content:"documentación interna · acceso";
			display:block;margin:0 0 16px;
			font-family:ui-monospace,Consolas,monospace;font-size:10.5px;
			letter-spacing:.18em;text-transform:uppercase;color:#8f8598;
		}
		#login form,#loginform{
			background:#12101a !important;border:1px solid #2b2436 !important;border-radius:18px;
			box-shadow:0 28px 70px -40px #000,0 0 0 1px rgba(255,255,255,.02) inset !important;padding:26px !important
		}
		#login label{color:#b7acb8;font-size:12.5px}
		#login input[type=text],#login input[type=password]{
			background:#0b0910 !important;color:#f7f1e8 !important;
			border:1px solid #2b2436 !important;border-radius:10px !important;padding:10px 11px !important
		}
		#login input:focus{border-color:#ff5a36 !important;box-shadow:0 0 0 3px rgba(255,90,54,.15) !important}
		#wp-submit{
			background:linear-gradient(135deg,#ffb59a,#ff5a36 58%,#e2491f) !important;border-color:transparent !important;border-radius:10px !important;
			color:#241007 !important;font-weight:700;padding:9px 18px !important;
			box-shadow:0 16px 34px -18px rgba(255,90,54,.9)
		}
		#wp-submit:hover{background:linear-gradient(135deg,#ffc9b4,#ff6a3d) !important}
		#nav,#backtoblog a{color:#9a90a2 !important}
		#nav a:hover,#backtoblog a:hover{color:#ffb09a !important}
		.jn-login-volver{text-align:center;margin:18px 0 0;font-family:ui-monospace,Consolas,monospace;font-size:11px;letter-spacing:.08em}
		.jn-login-volver a{color:#ffb09a !important;text-decoration:none}
		.jn-login-volver a:hover{color:#ffd0c0 !important}
	</style>
	<?php
});

add_action('login_footer', function () {
	echo '<p class="jn-login-volver"><a href="' . esc_url(home_url('/')) . '">← volver a la web</a></p>';
});

/* ─── portada cinematográfica ─── */
function jn_insertar_en_hero($html, $bloque) {
	$pos = strpos($html, 'jn-hero');
	if ($pos === false) {
		return $html;
	}
	$fin = strpos($html, '>', $pos);
	if ($fin === false) {
		return $html;
	}
	return substr($html, 0, $fin + 1) . $bloque . substr($html, $fin + 1);
}

function jn_insertar_tras_hero($html, $bloque) {
	$pos = strpos($html, 'jn-hero');
	if ($pos === false) {
		return $bloque . $html;
	}
	$ini = strrpos(substr($html, 0, $pos), '<div');
	if ($ini === false) {
		return $bloque . $html;
	}
	$i = $ini;
	$prof = 0;
	$largo = strlen($html);
	while ($i < $largo) {
		$abre = strpos($html, '<div', $i);
		$cierra = strpos($html, '</div', $i);
		if ($cierra === false) {
			return $bloque . $html;
		}
		if ($abre !== false && $abre < $cierra) {
			$prof++;
			$i = $abre + 4;
		} else {
			$prof--;
			$fin = $cierra + 6;
			$i = $fin;
			if ($prof === 0) {
				return substr($html, 0, $fin) . $bloque . substr($html, $fin);
			}
		}
	}
	return $bloque . $html;
}

function jn_bloque_hero_video() {
	$url = esc_url(jn_asset_uri('el-viaje.mp4'));
	return '<figure class="jn-hero-video" data-jn-cine>'
		. '<div class="jn-hero-video__marco">'
		. '<video class="jn-cine__video" src="' . $url . '" autoplay muted loop playsinline preload="metadata"></video>'
		. '<span class="jn-hero-video__tag">▷ el viaje</span>'
		. '<div class="jn-hero-video__pie">'
		. '<button type="button" data-jn-play aria-label="Pausar">❚❚</button>'
		. '<button type="button" data-jn-sonido aria-label="Activar sonido">🔇</button>'
		. '<button type="button" data-jn-pantalla aria-label="Pantalla completa">⛶</button>'
		. '<span class="jn-cine__tiempo">0:00</span>'
		. '</div></div>'
		. '<figcaption>el viaje · 7 min · 3 saltos</figcaption>'
		. '</figure>';
}

function jn_bloque_pelicula() {
	$url = esc_url(jn_asset_uri('el-viaje.mp4'));
	return '<section class="jn-cine" id="el-viaje" data-jn-cine>'
		. '<div class="jn-cine__cab">'
		. '<span class="jn-cine__tag">▷ el viaje · 7 min</span>'
		. '<h2>El viaje completo, <em>de principio a fin</em></h2>'
		. '<p>Siete minutos dentro de la red: cómo se encienden los nodos, cómo salta el paquete y qué ve cada salto.</p>'
		. '</div>'
		. '<div class="jn-cine__marco">'
		. '<video class="jn-cine__video" src="' . $url . '" muted playsinline preload="metadata"></video>'
		. '<div class="jn-cine__velo" aria-hidden="true"></div>'
		. '<div class="jn-cine__controles">'
		. '<button type="button" data-jn-play aria-label="Reproducir">▶</button>'
		. '<button type="button" data-jn-sonido aria-label="Activar sonido">🔇</button>'
		. '<button type="button" data-jn-pantalla aria-label="Pantalla completa">⛶</button>'
		. '<div class="jn-cine__barra" role="presentation"><i></i></div>'
		. '<span class="jn-cine__tiempo">0:00</span>'
		. '</div></div></section>';
}

add_filter('the_content', function ($contenido) {
	static $hecho = false;
	if ($hecho || is_admin() || !is_front_page() || !jn_hay_video()) {
		return $contenido;
	}
	if (get_the_ID() !== get_queried_object_id()) {
		return $contenido;
	}
	$hecho = true;
	$contenido = jn_insertar_en_hero($contenido, jn_bloque_hero_video());
	return jn_insertar_tras_hero($contenido, jn_bloque_pelicula());
}, 8);

/* ─── intro a pantalla completa (una vez por sesión) ─── */
add_action('wp_footer', function () {
	if (!is_front_page() || !jn_hay_video()) {
		return;
	}
	?>
	<div class="jn-intro" id="jn-intro" data-clave="jn-intro-v12" role="dialog" aria-modal="true" aria-label="Presentación de JumperNET">
		<video class="jn-intro__video" src="<?php echo esc_url(jn_asset_uri('el-viaje.mp4')); ?>" muted loop playsinline preload="metadata"></video>
		<div class="jn-intro__velo" aria-hidden="true"></div>
		<div class="jn-intro__marca">
			<span class="jn-intro__marca-logo" aria-hidden="true">↯</span>
			<span class="jn-intro__kicker">red educativa · el viaje</span>
			<h2 class="jn-intro__titulo">Jumper<em>NET</em></h2>
			<p class="jn-intro__sub">tu conexión <em>no va sola</em></p>
			<button type="button" class="jn-intro__saltar">entrar →</button>
			<span class="jn-intro__pista">o pulsa en cualquier sitio</span>
		</div>
		<div class="jn-intro__linea" aria-hidden="true"><i></i></div>
	</div>
	<noscript><style>.jn-intro{display:none!important}</style></noscript>
	<?php
}, 5);

/* ─── lectura y código: progreso + copiar ─── */
add_action('wp_footer', function () {
	if (!is_singular()) return;
	?>
	<div id="jn-progreso" aria-hidden="true"></div>
	<script>
	(function () {
		var barra = document.getElementById('jn-progreso');
		function pinta() {
			var h = document.documentElement;
			var max = h.scrollHeight - h.clientHeight;
			if (barra) barra.style.transform = 'scaleX(' + (max > 0 ? Math.min(1, h.scrollTop / max) : 0) + ')';
		}
		addEventListener('scroll', pinta, { passive: true });
		pinta();

		document.querySelectorAll('.entry-content pre').forEach(function (pre) {
			var boton = document.createElement('button');
			boton.type = 'button';
			boton.className = 'jn-copiar';
			boton.textContent = 'copiar';
			boton.setAttribute('aria-label', 'Copiar el bloque de código');
			boton.addEventListener('click', function () {
				var code = pre.querySelector('code');
				var texto = (code || pre).innerText;
				navigator.clipboard.writeText(texto).then(function () {
					boton.textContent = 'copiado ✓';
					boton.classList.add('hecho');
					setTimeout(function () { boton.textContent = 'copiar'; boton.classList.remove('hecho'); }, 1800);
				});
			});
			pre.appendChild(boton);
		});
	})();
	</script>
	<?php
});

/* ─── caja de serie al final de los artículos ─── */
add_filter('the_content', function ($contenido) {
	if (is_singular('post') && in_the_loop() && is_main_query()) {
		$articulos = array(
			'que-es-jumpernet'           => 'Qué es JumperNET y por qué existe',
			'arquitectura-completa'      => 'Arquitectura completa de la red',
			'seguridad'                  => 'Seguridad',
			'cifrado-de-los-saltos-jenc' => 'El cifrado de los saltos (JENC)',
			'guia-primeros-pasos'        => 'Guía: primeros pasos',
			'navegador-jumpernet'        => 'El navegador JumperNET',
			'extension-del-navegador'    => 'La extensión del navegador',
			'problemas-y-soluciones'     => 'Problemas y soluciones',
			'referencia-api'             => 'Referencia de la API',
			'despliegue-y-operacion'     => 'Despliegue y operación',
		);
		$items = '';
		foreach ($articulos as $slug => $titulo) {
			$items .= '<li><a href="/docs/' . $slug . '/">' . $titulo . '</a></li>';
		}
		$caja = '<aside class="jn-serie"><h2>Índice de la documentación</h2><ol>' . $items . '</ol>'
		      . '<a class="jn-volver" href="/docs/">⌂ volver al índice general</a></aside>';
		return $contenido . $caja;
	}
	return $contenido;
}, 20);

/* ═══════════════════════════════════════════════════════════════════
   PANEL AL INICIAR SESIÓN
   ═══════════════════════════════════════════════════════════════════ */

function jn_contar_adjuntos() {
	$total = 0;
	foreach ((array) wp_count_attachments() as $estado) {
		if (isset($estado->count)) {
			$total += (int) $estado->count;
		}
	}
	return $total;
}

function jn_contar_comentarios() {
	$c = wp_count_comments();
	return (int) $c->approved + (int) $c->moderated + (int) $c->spam;
}

function jn_acciones_rapidas() {
	$acciones = array();
	if (current_user_can('edit_posts')) {
		$acciones[] = array('✎', 'Nueva entrada', admin_url('post-new.php'), 'Escribe un artículo de la documentación');
	}
	if (current_user_can('edit_pages')) {
		$acciones[] = array('▤', 'Nueva página', admin_url('post-new.php?post_type=page'), 'Añade una página nueva al sitio');
	}
	if (current_user_can('upload_files')) {
		$acciones[] = array('⇪', 'Subir archivo', admin_url('media-new.php'), 'Imágenes, capturas y vídeos');
	}
	if (current_user_can('moderate_comments')) {
		$acciones[] = array('✉', 'Comentarios', admin_url('edit-comments.php'), 'Revisa lo que llega');
	}
	if (current_user_can('edit_theme_options')) {
		$acciones[] = array('◈', 'Personalizar', admin_url('customize.php'), 'Colores, cabecera y menús');
		$acciones[] = array('≡', 'Menús', admin_url('nav-menus.php'), 'Estructura de navegación');
	}
	if (current_user_can('manage_options')) {
		$acciones[] = array('⚙', 'Ajustes', admin_url('options-general.php'), 'Opciones generales del sitio');
	}
	$acciones[] = array('▶', 'Ver «El viaje»', home_url('/#el-viaje'), 'El vídeo de la portada');
	$acciones[] = array('⌂', 'Ver la web', home_url('/'), 'Abre el sitio publicado');
	return $acciones;
}

/* widget del escritorio */
add_action('wp_dashboard_setup', function () {
	if (!current_user_can('edit_posts')) return;
	wp_add_dashboard_widget('jn_panel', 'JumperNET · panel rápido', 'jn_panel_widget');
});

function jn_panel_widget() {
	$post     = wp_count_posts('post');
	$page     = wp_count_posts('page');
	$usuarios = count_users();
	$fichas   = array(
		array(isset($post->publish) ? (int) $post->publish : 0, 'entradas'),
		array(isset($page->publish) ? (int) $page->publish : 0, 'páginas'),
		array(jn_contar_adjuntos(), 'archivos'),
		array(jn_contar_comentarios(), 'comentarios'),
		array(current_user_can('list_users') ? (int) $usuarios['total_users'] : '—', 'usuarios'),
	);
	?>
	<div class="jn-panel">
		<div class="jn-panel__cab">
			<span class="jn-panel__logo" aria-hidden="true">↯</span>
			<div class="jn-panel__marca">
				<b>JumperNET</b>
				<span>documentación · v<?php echo esc_html(JN_VERSION); ?></span>
			</div>
			<span class="jn-panel__estado"><i></i>en línea</span>
		</div>

		<div class="jn-panel__stats">
			<?php foreach ($fichas as $ficha) : ?>
				<div class="jn-panel__stat">
					<b><?php echo esc_html((string) $ficha[0]); ?></b>
					<span><?php echo esc_html($ficha[1]); ?></span>
				</div>
			<?php endforeach; ?>
		</div>

		<h3 class="jn-panel__tit">Qué quieres hacer</h3>
		<div class="jn-panel__acciones">
			<?php foreach (jn_acciones_rapidas() as $accion) : ?>
				<a class="jn-panel__accion" href="<?php echo esc_url($accion[2]); ?>">
					<span class="jn-panel__icono" aria-hidden="true"><?php echo esc_html($accion[0]); ?></span>
					<b><?php echo esc_html($accion[1]); ?></b>
					<small><?php echo esc_html($accion[3]); ?></small>
				</a>
			<?php endforeach; ?>
		</div>

		<?php
		$recientes = get_posts(array(
			'numberposts' => 5,
			'post_type'   => 'post',
			'post_status' => array('publish', 'draft', 'pending', 'private'),
		));
		if ($recientes) :
			?>
			<h3 class="jn-panel__tit">Últimos documentos</h3>
			<ul class="jn-panel__lista">
				<?php foreach ($recientes as $doc) :
					$estado = ($doc->post_status === 'publish') ? 'publicado' : $doc->post_status;
					?>
					<li>
						<a href="<?php echo esc_url(get_edit_post_link($doc->ID)); ?>"><?php echo esc_html(get_the_title($doc) ?: '(sin título)'); ?></a>
						<span class="jn-panel__meta"><?php echo esc_html($estado); ?> · <?php echo esc_html(get_the_date('j M', $doc)); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<p class="jn-panel__pie">
			<a href="<?php echo esc_url(admin_url('admin.php?page=jumpernet')); ?>">Abrir el panel completo →</a>
		</p>
	</div>
	<?php
}

/* menú propio */
add_action('admin_menu', function () {
	add_menu_page('JumperNET', 'JumperNET', 'edit_posts', 'jumpernet', 'jn_pagina_admin', 'dashicons-superhero', 3);
});

function jn_pagina_admin() {
	if (!current_user_can('edit_posts')) return;

	$post     = wp_count_posts('post');
	$page     = wp_count_posts('page');
	$usuarios = count_users();
	$documentos = get_posts(array(
		'numberposts' => 30,
		'post_type'   => 'post',
		'post_status' => array('publish', 'draft', 'pending', 'private'),
	));
	?>
	<div class="wrap jn-adm">
		<div class="jn-adm-cab">
			<span class="jn-adm-marca" aria-hidden="true">↯</span>
			<div>
				<h1>JumperNET · panel</h1>
				<p>Hola<?php echo esc_html(wp_get_current_user()->display_name ? ', ' . wp_get_current_user()->display_name : ''); ?>. Todo lo que puedes hacer desde aquí.</p>
			</div>
			<div class="jn-adm-cab__acciones">
				<a class="jn-btn jn-btn--prin" href="<?php echo esc_url(home_url('/')); ?>" target="_blank" rel="noopener">ver la web ↗</a>
				<a class="jn-btn jn-btn--fant" href="<?php echo esc_url(home_url('/#el-viaje')); ?>" target="_blank" rel="noopener">▶ el viaje</a>
			</div>
		</div>

		<div class="jn-adm-stats">
			<div class="jn-adm-stat"><b><?php echo esc_html((string) (isset($post->publish) ? $post->publish : 0)); ?></b><span>entradas publicadas</span></div>
			<div class="jn-adm-stat"><b><?php echo esc_html((string) (isset($page->publish) ? $page->publish : 0)); ?></b><span>páginas</span></div>
			<div class="jn-adm-stat"><b><?php echo esc_html((string) jn_contar_adjuntos()); ?></b><span>archivos</span></div>
			<div class="jn-adm-stat"><b><?php echo esc_html((string) jn_contar_comentarios()); ?></b><span>comentarios</span></div>
			<div class="jn-adm-stat"><b><?php echo esc_html(current_user_can('list_users') ? (string) $usuarios['total_users'] : '—'); ?></b><span>usuarios</span></div>
			<div class="jn-adm-stat jn-adm-stat--ver"><b>v<?php echo esc_html(JN_VERSION); ?></b><span>tema activo</span></div>
		</div>

		<h2 class="jn-adm-tit">Accesos rápidos</h2>
		<div class="jn-adm-grid">
			<?php foreach (jn_acciones_rapidas() as $accion) : ?>
				<a class="jn-adm-card" href="<?php echo esc_url($accion[2]); ?>">
					<span class="jn-adm-card__icono" aria-hidden="true"><?php echo esc_html($accion[0]); ?></span>
					<b><?php echo esc_html($accion[1]); ?></b>
					<small><?php echo esc_html($accion[3]); ?></small>
				</a>
			<?php endforeach; ?>
		</div>

		<div class="jn-adm-cols">
			<div class="jn-adm-caja">
				<h2 class="jn-adm-tit">Documentos</h2>
				<?php if ($documentos) : ?>
					<table class="jn-adm-tabla">
						<thead>
							<tr><th>Título</th><th>Estado</th><th>Fecha</th><th></th></tr>
						</thead>
						<tbody>
							<?php foreach ($documentos as $doc) : ?>
								<tr>
									<td><a href="<?php echo esc_url(get_edit_post_link($doc->ID)); ?>"><?php echo esc_html(get_the_title($doc) ?: '(sin título)'); ?></a></td>
									<td><span class="jn-adm-chip"><?php echo esc_html($doc->post_status === 'publish' ? 'publicado' : $doc->post_status); ?></span></td>
									<td><?php echo esc_html(get_the_date('j M Y', $doc)); ?></td>
									<td class="jn-adm-tabla__acc">
										<a href="<?php echo esc_url(get_edit_post_link($doc->ID)); ?>">editar</a>
										<a href="<?php echo esc_url(get_permalink($doc)); ?>" target="_blank" rel="noopener">ver ↗</a>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else : ?>
					<p class="jn-adm-vacio">Todavía no hay documentos. <a href="<?php echo esc_url(admin_url('post-new.php')); ?>">Escribe el primero</a>.</p>
				<?php endif; ?>
			</div>

			<div class="jn-adm-caja">
				<h2 class="jn-adm-tit">El viaje</h2>
				<?php if (jn_hay_video()) : ?>
					<video class="jn-adm-video" src="<?php echo esc_url(jn_asset_uri('el-viaje.mp4')); ?>" controls preload="metadata" playsinline></video>
					<p class="jn-adm-nota">7:16 · 1280×720. Se reproduce en bucle arriba a la derecha del título de la portada, completo en la sección «El viaje» y una vez por sesión a pantalla completa al entrar.</p>
					<p class="jn-adm-nota"><a href="<?php echo esc_url(home_url('/#el-viaje')); ?>" target="_blank" rel="noopener">Abrir en la portada ↗</a></p>
				<?php else : ?>
					<p class="jn-adm-vacio">No se encuentra <code>assets/el-viaje.mp4</code>.</p>
				<?php endif; ?>

				<h2 class="jn-adm-tit">Notas de la versión</h2>
				<ul class="jn-adm-lista">
					<li><b>v1.3.0</b> · vídeo arriba a la derecha del título y película completa de 7 min en la portada, portada más ancha y renovada.</li>
					<li><b>v1.2.0</b> · vídeo «El viaje», portada cinematográfica, fondo animado, cabecera y logo nuevos, panel de inicio.</li>
					<li><b>v1.1.0</b> · paleta coral/violeta, lectura más cómoda y copia rápida de código.</li>
				</ul>
			</div>
		</div>
	</div>
	<?php
}

/* barra de administración */
add_action('admin_bar_menu', function ($bar) {
	if (!is_admin_bar_showing() && !is_admin()) return;

	$bar->add_node(array(
		'id'    => 'jn-crear',
		'title' => '＋ crear',
		'href'  => current_user_can('edit_posts') ? admin_url('post-new.php') : admin_url(),
		'meta'  => array('title' => 'Crear contenido'),
	));
	$hijos = array(
		'jn-crear-entrada' => array('edit_posts', 'Entrada', 'post-new.php'),
		'jn-crear-pagina'  => array('edit_pages', 'Página', 'post-new.php?post_type=page'),
		'jn-crear-medio'   => array('upload_files', 'Archivo', 'media-new.php'),
		'jn-crear-usuario' => array('create_users', 'Usuario', 'user-new.php'),
	);
	foreach ($hijos as $id => $hijo) {
		if (!current_user_can($hijo[0])) continue;
		$bar->add_node(array(
			'id'     => $id,
			'parent' => 'jn-crear',
			'title'  => $hijo[1],
			'href'   => admin_url($hijo[2]),
		));
	}
	if (current_user_can('edit_posts')) {
		$bar->add_node(array(
			'id'    => 'jn-panel',
			'title' => '↯ JumperNET',
			'href'  => admin_url('admin.php?page=jumpernet'),
		));
	}
	$bar->add_node(array(
		'id'    => 'jn-viaje',
		'title' => '▶ el viaje',
		'href'  => home_url('/#el-viaje'),
	));
}, 40);

/* pie del panel */
add_filter('admin_footer_text', function () {
	return 'JumperNET · documentación interna · <span style="color:#ff8a5f">v' . esc_html(JN_VERSION) . '</span>';
});
add_filter('update_footer', function () {
	return 'hecho con ♥ para la red';
}, 11);

/* estilos del panel */
add_action('admin_head', function () {
	?>
	<style>
		#wpadminbar{background:#0d0a14!important}
		#wpadminbar .ab-item,#wpadminbar a.ab-item,#wpadminbar #wp-toolbar span.ab-label{color:#ece4f0!important}
		#wpadminbar .ab-top-menu>li:hover>.ab-item,#wpadminbar .ab-top-menu>li.hover>.ab-item{background:#1b1526!important;color:#fff!important}
		#wpadminbar #wp-admin-bar-jn-crear>.ab-item{background:linear-gradient(135deg,#ff8a63,#ff5a36)!important;color:#241007!important;font-weight:700}
		#wpadminbar #wp-admin-bar-jn-viaje>.ab-item{color:#ffb09a!important}

		.jn-panel{font-size:13px}
		.jn-panel__cab{display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:14px;background:radial-gradient(420px 160px at 92% -40%,rgba(255,90,54,.28),transparent 66%),linear-gradient(180deg,#191323,#0f0c15);border:1px solid #2b2436;margin:0 0 14px}
		.jn-panel__logo{display:grid;place-items:center;width:36px;height:36px;border-radius:11px;font-size:18px;font-weight:800;color:#1b0a04;background:linear-gradient(145deg,#ffb59a,#ff5a36 55%,#b06aff)}
		.jn-panel__marca b{display:block;color:#fff;font-size:15px;letter-spacing:.02em}
		.jn-panel__marca span{color:#a99fae;font-size:11px;font-family:ui-monospace,Consolas,monospace}
		.jn-panel__estado{margin-left:auto;display:inline-flex;align-items:center;gap:6px;font-family:ui-monospace,Consolas,monospace;font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:#9ff5df;border:1px solid rgba(51,214,192,.4);background:rgba(51,214,192,.1);border-radius:999px;padding:3px 10px}
		.jn-panel__estado i{width:6px;height:6px;border-radius:50%;background:#33d6c0;box-shadow:0 0 0 3px rgba(51,214,192,.18)}
		.jn-panel__stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(78px,1fr));gap:8px;margin-bottom:16px}
		.jn-panel__stat{border:1px solid #2b2436;border-radius:11px;padding:9px 11px;background:rgba(255,255,255,.02);text-align:center}
		.jn-panel__stat b{display:block;font-size:19px;color:#ffb09a;font-family:ui-monospace,Consolas,monospace;line-height:1.2}
		.jn-panel__stat span{font-size:10.5px;color:#a99fae}
		.jn-panel__tit{margin:16px 0 9px!important;font-size:11px!important;letter-spacing:.16em;text-transform:uppercase;color:#a99fae!important;font-family:ui-monospace,Consolas,monospace}
		.jn-panel__acciones{display:grid;grid-template-columns:repeat(auto-fit,minmax(148px,1fr));gap:8px}
		.jn-panel__accion{display:grid;gap:1px;padding:10px 12px;border:1px solid #2b2436;border-radius:11px;background:#0e0b13;text-decoration:none;transition:border-color .2s ease,transform .2s ease,background .2s ease}
		.jn-panel__accion:hover{transform:translateY(-2px);border-color:rgba(255,90,54,.55);background:#14101b}
		.jn-panel__icono{color:#ff8a63;font-size:13px;line-height:1}
		.jn-panel__accion b{color:#f7f1e8;font-size:12.5px;font-weight:600}
		.jn-panel__accion small{color:#8f8598;font-size:10.5px;line-height:1.35}
		.jn-panel__lista{margin:0;padding:0;list-style:none}
		.jn-panel__lista li{display:flex;justify-content:space-between;gap:10px;padding:7px 2px;border-bottom:1px solid #221b2c;font-size:12.5px}
		.jn-panel__lista li:last-child{border-bottom:0}
		.jn-panel__lista a{color:#ffb09a;text-decoration:none}
		.jn-panel__lista a:hover{color:#ffd0c0}
		.jn-panel__meta{color:#8f8598;font-family:ui-monospace,Consolas,monospace;font-size:10px;white-space:nowrap}
		.jn-panel__pie{margin:14px 0 0!important}
		.jn-panel__pie a{font-family:ui-monospace,Consolas,monospace;font-size:11.5px;color:#ff8a63;text-decoration:none}
		#jn_panel .inside{background:#0b0910;color:#d9d0dd}

		.jn-adm{max-width:1180px;color:#d9d0dd}
		.jn-adm-cab{display:flex;align-items:center;gap:16px;flex-wrap:wrap;margin:18px 0 20px;padding:20px 22px;border-radius:18px;background:radial-gradient(620px 220px at 92% -40%,rgba(255,90,54,.26),transparent 66%),radial-gradient(420px 200px at 4% 120%,rgba(139,123,255,.22),transparent 60%),linear-gradient(180deg,#191323,#0f0c15);border:1px solid #2b2436;box-shadow:0 26px 60px -46px #000}
		.jn-adm-marca{display:grid;place-items:center;width:46px;height:46px;border-radius:14px;font-size:22px;font-weight:800;color:#1b0a04;background:linear-gradient(145deg,#ffb59a,#ff5a36 55%,#b06aff);box-shadow:0 14px 30px -14px rgba(255,90,54,.9)}
		.jn-adm-cab h1{margin:0;font-size:20px;color:#fff}
		.jn-adm-cab p{margin:2px 0 0;color:#a99fae;font-size:12.5px}
		.jn-adm-cab__acciones{margin-left:auto;display:flex;gap:8px;flex-wrap:wrap}
		.jn-btn{display:inline-flex;align-items:center;gap:6px;border-radius:10px;padding:9px 15px;font-size:12.5px;font-weight:600;text-decoration:none;border:1px solid transparent;transition:filter .2s ease,transform .2s ease}
		.jn-btn:hover{transform:translateY(-1px)}
		.jn-btn--prin{background:linear-gradient(135deg,#ffb59a,#ff5a36 60%,#e2491f);color:#241007!important}
		.jn-btn--fant{background:rgba(255,255,255,.05);border-color:#2b2436;color:#f0e8f2!important}
		.jn-adm-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:26px}
		.jn-adm-stat{padding:14px 16px;border:1px solid #2b2436;border-radius:14px;background:linear-gradient(180deg,#15111d,#0d0b12)}
		.jn-adm-stat b{display:block;font-size:24px;line-height:1.1;color:#ffb09a;font-family:ui-monospace,Consolas,monospace}
		.jn-adm-stat span{font-size:11px;color:#a99fae}
		.jn-adm-stat--ver b{color:#c9c2ff}
		.jn-adm-tit{margin:0 0 12px!important;font-size:12px!important;letter-spacing:.18em;text-transform:uppercase;color:#a99fae!important;font-family:ui-monospace,Consolas,monospace}
		.jn-adm-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px;margin-bottom:28px}
		.jn-adm-card{display:grid;gap:2px;padding:15px 17px;border:1px solid #2b2436;border-radius:14px;background:linear-gradient(180deg,#14101b,#0d0b12);text-decoration:none;transition:transform .2s ease,border-color .2s ease,box-shadow .2s ease}
		.jn-adm-card:hover{transform:translateY(-3px);border-color:rgba(255,90,54,.55);box-shadow:0 18px 40px -28px rgba(255,90,54,.6)}
		.jn-adm-card__icono{color:#ff8a63;font-size:15px;line-height:1.2}
		.jn-adm-card b{color:#f7f1e8;font-size:13.5px}
		.jn-adm-card small{color:#8f8598;font-size:11px;line-height:1.4}
		.jn-adm-cols{display:grid;grid-template-columns:1.6fr 1fr;gap:16px;align-items:start}
		.jn-adm-caja{padding:18px 20px;border:1px solid #2b2436;border-radius:16px;background:linear-gradient(180deg,#12101a,#0b0910)}
		.jn-adm-tabla{width:100%;border-collapse:collapse;font-size:12.5px}
		.jn-adm-tabla th{text-align:left;font-family:ui-monospace,Consolas,monospace;font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:#8f8598;padding:6px 8px;border-bottom:1px solid #2b2436}
		.jn-adm-tabla td{padding:9px 8px;border-bottom:1px solid #201a29;color:#d9d0dd;vertical-align:middle}
		.jn-adm-tabla tr:last-child td{border-bottom:0}
		.jn-adm-tabla a{color:#ffb09a;text-decoration:none}
		.jn-adm-tabla__acc{text-align:right;white-space:nowrap}
		.jn-adm-tabla__acc a{margin-left:10px;font-family:ui-monospace,Consolas,monospace;font-size:11px}
		.jn-adm-chip{display:inline-block;font-family:ui-monospace,Consolas,monospace;font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:#9ff5df;border:1px solid rgba(51,214,192,.35);background:rgba(51,214,192,.1);border-radius:999px;padding:2px 8px}
		.jn-adm-video{width:100%;border-radius:12px;border:1px solid #2b2436;display:block;margin-bottom:10px;background:#08060d}
		.jn-adm-nota{color:#a99fae;font-size:11.5px;margin:0 0 8px}
		.jn-adm-nota a{color:#ff8a63;text-decoration:none}
		.jn-adm-lista{margin:0;padding-left:16px;color:#b7acb8;font-size:12px;line-height:1.6}
		.jn-adm-lista b{color:#fff}
		.jn-adm-vacio{color:#8f8598;font-size:12.5px}
		@media (max-width:960px){.jn-adm-cols{grid-template-columns:1fr}}
	</style>
	<?php
});
