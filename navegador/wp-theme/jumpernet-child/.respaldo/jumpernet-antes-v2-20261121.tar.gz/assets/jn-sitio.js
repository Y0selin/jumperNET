/* JumperNET · v1.3.0
   Fondo vivo, intro cinematográfica y controles del vídeo «El viaje». */
(function () {
	'use strict';

	var doc = document;
	var body = doc.body;
	var cfg = window.JN || {};
	var reduce = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)').matches : false;

	function $(sel, ctx) { return (ctx || doc).querySelector(sel); }
	function $$(sel, ctx) { return Array.prototype.slice.call((ctx || doc).querySelectorAll(sel)); }

	/* ───────── 1 · campo de estrellas del fondo ───────── */
	(function estrellas() {
		if (reduce) return;
		var lienzo = doc.createElement('canvas');
		lienzo.id = 'jn-estrellas';
		lienzo.setAttribute('aria-hidden', 'true');
		body.insertBefore(lienzo, body.firstChild);

		var ctx = lienzo.getContext && lienzo.getContext('2d');
		if (!ctx) return;

		var paleta = ['#ff7a55', '#ffb09a', '#8b7bff', '#33d6c0', '#f7f1e8'];
		var dpr = Math.min(window.devicePixelRatio || 1, 2);
		var ancho = 0, alto = 0, t = 0, raf = 0;
		var puntos = [];

		function medir() {
			ancho = window.innerWidth;
			alto = window.innerHeight;
			lienzo.width = Math.round(ancho * dpr);
			lienzo.height = Math.round(alto * dpr);
			lienzo.style.width = ancho + 'px';
			lienzo.style.height = alto + 'px';
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

			var n = Math.max(26, Math.min(86, Math.round(ancho * alto / 24000)));
			puntos = [];
			for (var i = 0; i < n; i++) {
				puntos.push({
					x: Math.random() * ancho,
					y: Math.random() * alto,
					r: 0.6 + Math.random() * 1.7,
					vy: 0.06 + Math.random() * 0.22,
					vx: (Math.random() - 0.5) * 0.12,
					f: 0.4 + Math.random() * 1.6,
					p: Math.random() * Math.PI * 2,
					c: paleta[(Math.random() * paleta.length) | 0]
				});
			}
		}

		function pintar() {
			raf = 0;
			t += 0.016;
			ctx.clearRect(0, 0, ancho, alto);
			for (var i = 0; i < puntos.length; i++) {
				var p = puntos[i];
				p.y -= p.vy;
				p.x += p.vx;
				if (p.y < -8) { p.y = alto + 8; p.x = Math.random() * ancho; }
				if (p.x < -8) p.x = ancho + 8;
				if (p.x > ancho + 8) p.x = -8;

				var a = 0.2 + Math.abs(Math.sin(t * p.f + p.p)) * 0.65;
				ctx.globalAlpha = a;
				ctx.fillStyle = p.c;
				ctx.beginPath();
				ctx.arc(p.x, p.y, p.r, 0, 6.2832);
				ctx.fill();

				if (p.r > 1.5) {
					ctx.globalAlpha = a * 0.16;
					ctx.beginPath();
					ctx.arc(p.x, p.y, p.r * 4.6, 0, 6.2832);
					ctx.fill();
				}
			}
			ctx.globalAlpha = 1;
			raf = requestAnimationFrame(pintar);
		}

		function arrancar() {
			if (!raf && !doc.hidden) raf = requestAnimationFrame(pintar);
		}

		var espera;
		window.addEventListener('resize', function () {
			clearTimeout(espera);
			espera = setTimeout(medir, 180);
		}, { passive: true });

		doc.addEventListener('visibilitychange', function () {
			if (doc.hidden) {
				if (raf) { cancelAnimationFrame(raf); raf = 0; }
			} else {
				arrancar();
			}
		});

		medir();
		arrancar();
	})();

	/* ───────── 2 · foco que sigue al cursor ───────── */
	(function foco() {
		if (reduce) return;
		if (!window.matchMedia || !window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;

		var el = doc.createElement('div');
		el.id = 'jn-foco';
		el.setAttribute('aria-hidden', 'true');
		body.appendChild(el);

		var x = window.innerWidth / 2, y = window.innerHeight / 2;
		var cx = x, cy = y, pedido = false;

		window.addEventListener('pointermove', function (e) {
			if (e.pointerType !== 'mouse') return;
			x = e.clientX;
			y = e.clientY;
			el.style.opacity = '1';
			if (!pedido) {
				pedido = true;
				requestAnimationFrame(mover);
			}
		}, { passive: true });

		function mover() {
			cx += (x - cx) * 0.12;
			cy += (y - cy) * 0.12;
			el.style.transform = 'translate3d(' + cx + 'px,' + cy + 'px,0)';
			if (Math.abs(x - cx) > 0.5 || Math.abs(y - cy) > 0.5) {
				requestAnimationFrame(mover);
			} else {
				pedido = false;
			}
		}
	})();

	/* ───────── 3 · cabecera al hacer scroll ───────── */
	(function cabecera() {
		var cab = $('.wp-site-blocks > header') || $('header.wp-block-template-part');
		if (!cab) return;
		var marca = function () {
			cab.classList.toggle('jn-scrolled', window.scrollY > 14);
		};
		window.addEventListener('scroll', marca, { passive: true });
		marca();
	})();

	/* ───────── 4 · aparición de bloques al entrar en pantalla ───────── */
	(function revelar() {
		if (reduce || !('IntersectionObserver' in window)) return;
		var sel = '.jn-hero,.jn-stats div,.jn-card,.jn-cine,.jn-serie,.jn-nota-pie,'
			+ '.entry-content h2,.entry-content pre,.entry-content table,.entry-content blockquote';

		var obs = new IntersectionObserver(function (entradas) {
			entradas.forEach(function (en) {
				if (!en.isIntersecting) return;
				var el = en.target;
				el.classList.add('jn-visible');
				obs.unobserve(el);
				setTimeout(function () {
					el.classList.remove('jn-reveal', 'jn-visible');
					el.style.transitionDelay = '';
				}, 920);
			});
		}, { threshold: 0.08, rootMargin: '0px 0px -6% 0px' });

		$$(sel).forEach(function (el, i) {
			if (el.closest('.jn-intro')) return;
			el.classList.add('jn-reveal');
			el.style.transitionDelay = (Math.min(i % 6, 5) * 45) + 'ms';
			obs.observe(el);
		});
	})();

	/* ───────── 5 · intro a pantalla completa ───────── */
	(function intro() {
		var capa = doc.getElementById('jn-intro');
		if (!capa) return;

		var video = $('.jn-intro__video', capa);
		var clave = capa.getAttribute('data-clave') || 'jn-intro';
		var visto = false;
		var cerrado = false;

		try { visto = sessionStorage.getItem(clave) === '1'; } catch (e) {}

		function cerrar(instante) {
			if (cerrado) return;
			cerrado = true;
			try { sessionStorage.setItem(clave, '1'); } catch (e) {}
			body.classList.remove('jn-intro-abierto');
			if (video) video.pause();

			if (instante || reduce) {
				if (capa.parentNode) capa.parentNode.removeChild(capa);
				return;
			}
			capa.classList.add('jn-intro--fuera');
			window.setTimeout(function () {
				if (capa.parentNode) capa.parentNode.removeChild(capa);
			}, 900);
		}

		if (reduce || visto) {
			cerrar(true);
			return;
		}

		body.classList.add('jn-intro-abierto');

		if (video) {
			video.muted = true;
			var p = video.play();
			if (p && p.catch) p.catch(function () {});
			video.addEventListener('ended', function () { cerrar(false); });
		}

		var boton = $('.jn-intro__saltar', capa);
		if (boton) {
			boton.addEventListener('click', function (e) {
				e.stopPropagation();
				cerrar(false);
			});
		}
		capa.addEventListener('click', function () { cerrar(false); });
		doc.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') cerrar(false);
		});

		window.setTimeout(function () { cerrar(false); }, 8200);
	})();

	/* ───────── 6 · controles del vídeo «El viaje» ───────── */
	(function cine() {
		$$('[data-jn-cine]').forEach(function (caja) {
			var v = $('.jn-cine__video', caja);
			if (!v) return;

			var btnPlay = $('[data-jn-play]', caja);
			var btnSonido = $('[data-jn-sonido]', caja);
			var btnPantalla = $('[data-jn-pantalla]', caja);
			var barra = $('.jn-cine__barra', caja);
			var relleno = $('.jn-cine__barra i', caja);
			var tiempo = $('.jn-cine__tiempo', caja);

			function formato(s) {
				if (!isFinite(s) || s < 0) s = 0;
				var m = Math.floor(s / 60);
				var r = Math.floor(s % 60);
				return m + ':' + (r < 10 ? '0' : '') + r;
			}

			function pintarTiempo() {
				var d = v.duration || 0;
				var a = v.currentTime || 0;
				if (relleno) relleno.style.transform = 'scaleX(' + (d ? Math.min(1, a / d) : 0) + ')';
				if (tiempo) tiempo.textContent = formato(a) + ' / ' + formato(d);
			}

			function refrescar() {
				if (btnPlay) {
					btnPlay.textContent = v.paused ? '▶' : '❚❚';
					btnPlay.setAttribute('aria-label', v.paused ? 'Reproducir' : 'Pausar');
				}
				if (btnSonido) {
					btnSonido.textContent = v.muted ? '🔇' : '🔊';
					btnSonido.setAttribute('aria-label', v.muted ? 'Activar sonido' : 'Silenciar');
				}
			}

			v.addEventListener('timeupdate', pintarTiempo);
			v.addEventListener('loadedmetadata', pintarTiempo);
			v.addEventListener('play', refrescar);
			v.addEventListener('pause', refrescar);
			v.addEventListener('volumechange', refrescar);
			pintarTiempo();
			refrescar();

			if (btnPlay) {
				btnPlay.addEventListener('click', function () {
					if (v.paused) {
						var p = v.play();
						if (p && p.catch) p.catch(function () {});
					} else {
						v.pause();
					}
				});
			}

			if (btnSonido) {
				btnSonido.addEventListener('click', function () {
					v.muted = !v.muted;
					if (!v.muted) v.volume = 1;
					refrescar();
				});
			}

			if (btnPantalla) {
				btnPantalla.addEventListener('click', function () {
					var marco = $('.jn-hero-video__marco', caja) || $('.jn-cine__marco', caja) || caja;
					if (doc.fullscreenElement) {
						if (doc.exitFullscreen) doc.exitFullscreen();
					} else if (marco.requestFullscreen) {
						marco.requestFullscreen();
					}
				});
			}

			if (barra) {
				barra.addEventListener('click', function (e) {
					var r = barra.getBoundingClientRect();
					if (v.duration && r.width) {
						v.currentTime = ((e.clientX - r.left) / r.width) * v.duration;
					}
				});
			}

			if ('IntersectionObserver' in window) {
				new IntersectionObserver(function (entradas) {
					entradas.forEach(function (en) {
						if (!en.isIntersecting && !v.paused && !doc.fullscreenElement) v.pause();
					});
				}, { threshold: 0.15 }).observe(caja);
			}
		});
	})();

	/* ───────── 7 · utilidad pública ───────── */
	window.JNfront = {
		version: '1.3.0',
		hayVideo: !!cfg.video
	};
})();
