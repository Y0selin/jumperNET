/*
 * JumperNET · experiencias del sitio
 * v2.1.0
 *
 * Nada de lo que hay aquí abre conexiones, ejecuta comandos ni mide la red.
 * El mapa, el viaje, el cifrado y la terminal son demostraciones educativas.
 */
(function () {
	'use strict';

	var JN = window.JN || {};
	var reducido = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var raiz = document.documentElement;

	window.JNfront = { version: JN.version || '2.1.0', reducido: reducido };

	/* ────────────────────────────────────────────────────────────────
	   TEMA CLARO / OSCURO
	   ──────────────────────────────────────────────────────────────── */

	var COLORES = {};

	function leerColores() {
		var cs = getComputedStyle(raiz);
		COLORES.coral = (cs.getPropertyValue('--jn-coral') || '#e85a33').trim();
		COLORES.tinta = (cs.getPropertyValue('--jn-tinta') || '#0e2233').trim();
		COLORES.oscuro = raiz.getAttribute('data-jn-tema') === 'oscuro';
		document.dispatchEvent(new CustomEvent('jn:tema', { detail: COLORES }));
	}

	function aplicarTema(modo, guardar) {
		var oscuro = modo === 'oscuro';
		raiz.setAttribute('data-jn-tema', oscuro ? 'oscuro' : 'claro');
		raiz.style.colorScheme = oscuro ? 'dark' : 'light';

		document.querySelectorAll('[data-jn-tema-btn]').forEach(function (btn) {
			btn.setAttribute('aria-pressed', oscuro ? 'true' : 'false');
			btn.setAttribute('aria-label', oscuro ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro');
			var txt = btn.querySelector('.jn-fab__txt');
			if (txt) txt.textContent = oscuro ? 'claro' : 'oscuro';
		});

		document.querySelectorAll('[data-jn-modo]').forEach(function (el) {
			el.textContent = oscuro ? 'oscuro' : 'claro';
		});

		if (guardar) {
			try { localStorage.setItem('jn-tema', oscuro ? 'oscuro' : 'claro'); } catch (e) {}
		}
		leerColores();
	}

	function iniciarTema() {
		var actual = raiz.getAttribute('data-jn-tema') === 'oscuro' ? 'oscuro' : 'claro';
		aplicarTema(actual, false);

		document.querySelectorAll('[data-jn-tema-btn]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var modo = raiz.getAttribute('data-jn-tema') === 'oscuro' ? 'claro' : 'oscuro';
				aplicarTema(modo, true);
			});
		});

		if (window.matchMedia) {
			var mq = window.matchMedia('(prefers-color-scheme: dark)');
			var alCambiar = function (e) {
				var guardado = null;
				try { guardado = localStorage.getItem('jn-tema'); } catch (err) {}
				if (!guardado) aplicarTema(e.matches ? 'oscuro' : 'claro', false);
			};
			if (mq.addEventListener) mq.addEventListener('change', alCambiar);
			else if (mq.addListener) mq.addListener(alCambiar);
		}
	}

	/* ────────────────────────────────────────────────────────────────
	   FONDO DE RED
	   Nodos y enlaces suaves. Reaccionan al ratón sin secuestrarlo.
	   ──────────────────────────────────────────────────────────────── */

	function iniciarRed() {
		if (reducido) return;

		var lienzo = document.createElement('canvas');
		lienzo.id = 'jn-red';
		lienzo.setAttribute('aria-hidden', 'true');
		document.body.appendChild(lienzo);

		var ctx = lienzo.getContext('2d');
		if (!ctx) return;

		var ancho = 0, alto = 0, dpr = 1;
		var nodos = [];
		var raton = { x: -999, y: -999, activo: false };
		var vivo = true;

		function medir() {
			dpr = Math.min(window.devicePixelRatio || 1, 2);
			ancho = window.innerWidth;
			alto = window.innerHeight;
			lienzo.width = Math.floor(ancho * dpr);
			lienzo.height = Math.floor(alto * dpr);
			lienzo.style.width = ancho + 'px';
			lienzo.style.height = alto + 'px';
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		}

		function crearNodos() {
			var total = Math.max(16, Math.min(48, Math.round((ancho * alto) / 42000)));
			nodos = [];
			for (var i = 0; i < total; i++) {
				nodos.push({
					x: Math.random() * ancho,
					y: Math.random() * alto,
					vx: (Math.random() - 0.5) * 0.34,
					vy: (Math.random() - 0.5) * 0.34,
					r: 1 + Math.random() * 1.7
				});
			}
		}

		function color(c, alfa) {
			return 'rgba(' + c + ',' + alfa + ')';
		}

		function rgbDe(hex) {
			var h = hex.replace('#', '');
			if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
			var n = parseInt(h, 16);
			if (isNaN(n)) return '232,90,51';
			return ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255);
		}

		var coral = '232,90,51';
		var tinta = '16,58,90';
		try {
			var cs0 = getComputedStyle(raiz);
			coral = rgbDe(cs0.getPropertyValue('--jn-coral') || '#e85a33');
			tinta = raiz.getAttribute('data-jn-tema') === 'oscuro' ? '150,195,225' : '16,58,90';
		} catch (e) {}
		document.addEventListener('jn:tema', function (e) {
			coral = rgbDe(e.detail.coral || '#e85a33');
			tinta = e.detail.oscuro ? '150,195,225' : '16,58,90';
		});

		function pintar() {
			if (!vivo) return;
			ctx.clearRect(0, 0, ancho, alto);

			for (var i = 0; i < nodos.length; i++) {
				var n = nodos[i];
				n.x += n.vx;
				n.y += n.vy;
				if (n.x < -20) n.x = ancho + 20;
				if (n.x > ancho + 20) n.x = -20;
				if (n.y < -20) n.y = alto + 20;
				if (n.y > alto + 20) n.y = -20;
			}

			for (var a = 0; a < nodos.length; a++) {
				var na = nodos[a];
				for (var b = a + 1; b < nodos.length; b++) {
					var nb = nodos[b];
					var dx = na.x - nb.x;
					var dy = na.y - nb.y;
					var d2 = dx * dx + dy * dy;
					if (d2 < 19600) {
						var alfa = (1 - Math.sqrt(d2) / 140) * 0.22;
						ctx.strokeStyle = color(tinta, alfa.toFixed(3));
						ctx.lineWidth = 0.7;
						ctx.beginPath();
						ctx.moveTo(na.x, na.y);
						ctx.lineTo(nb.x, nb.y);
						ctx.stroke();
					}
				}

				if (raton.activo) {
					var mx = na.x - raton.x;
					var my = na.y - raton.y;
					var md = Math.sqrt(mx * mx + my * my);
					if (md < 190) {
						ctx.strokeStyle = color(coral, ((1 - md / 190) * 0.34).toFixed(3));
						ctx.lineWidth = 0.9;
						ctx.beginPath();
						ctx.moveTo(na.x, na.y);
						ctx.lineTo(raton.x, raton.y);
						ctx.stroke();
					}
				}
			}

			for (var k = 0; k < nodos.length; k++) {
				var nodo = nodos[k];
				var cerca = raton.activo && Math.hypot(nodo.x - raton.x, nodo.y - raton.y) < 190;
				ctx.fillStyle = cerca ? color(coral, 0.85) : color(coral, 0.45);
				ctx.beginPath();
				ctx.arc(nodo.x, nodo.y, nodo.r, 0, Math.PI * 2);
				ctx.fill();
			}

			requestAnimationFrame(pintar);
		}

		medir();
		crearNodos();
		pintar();

		var espera;
		window.addEventListener('resize', function () {
			clearTimeout(espera);
			espera = setTimeout(function () { medir(); crearNodos(); }, 180);
		}, { passive: true });

		window.addEventListener('pointermove', function (e) {
			raton.x = e.clientX;
			raton.y = e.clientY;
			raton.activo = true;
		}, { passive: true });

		window.addEventListener('pointerleave', function () { raton.activo = false; }, { passive: true });

		document.addEventListener('visibilitychange', function () {
			if (document.hidden) {
				vivo = false;
			} else if (!vivo) {
				vivo = true;
				pintar();
			}
		});
	}

	/* ────────────────────────────────────────────────────────────────
	   NIEVE DE TEMPORADA
	   ──────────────────────────────────────────────────────────────── */

	function iniciarNieve() {
		if (!JN.navidad || reducido) return;

		var lienzo = document.createElement('canvas');
		lienzo.id = 'jn-nieve';
		lienzo.setAttribute('aria-hidden', 'true');
		document.body.appendChild(lienzo);

		var ctx = lienzo.getContext('2d');
		if (!ctx) return;

		var ancho = 0, alto = 0, dpr = 1;
		var copos = [];
		var brillo = raiz.getAttribute('data-jn-tema') === 'oscuro' ? '255,255,255' : '105,145,175';
		var vivo = true;
		var tiempo = 0;

		function medir() {
			dpr = Math.min(window.devicePixelRatio || 1, 2);
			ancho = window.innerWidth;
			alto = window.innerHeight;
			lienzo.width = Math.floor(ancho * dpr);
			lienzo.height = Math.floor(alto * dpr);
			lienzo.style.width = ancho + 'px';
			lienzo.style.height = alto + 'px';
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		}

		function crear() {
			var total = Math.max(24, Math.min(70, Math.round(ancho / 22)));
			copos = [];
			for (var i = 0; i < total; i++) {
				copos.push({
					x: Math.random() * ancho,
					y: Math.random() * alto,
					r: 0.7 + Math.random() * 2,
					vy: 0.22 + Math.random() * 0.5,
					vx: (Math.random() - 0.5) * 0.32,
					fase: Math.random() * Math.PI * 2
				});
			}
		}

		document.addEventListener('jn:tema', function (e) {
			brillo = e.detail.oscuro ? '255,255,255' : '105,145,175';
		});

		function copo(c) {
			ctx.fillStyle = 'rgba(' + brillo + ',' + (0.25 + c.r / 5).toFixed(2) + ')';
			ctx.beginPath();
			ctx.arc(c.x, c.y, c.r, 0, Math.PI * 2);
			ctx.fill();
		}

		function pintar() {
			if (!vivo) return;
			tiempo += 0.01;
			ctx.clearRect(0, 0, ancho, alto);
			for (var i = 0; i < copos.length; i++) {
				var c = copos[i];
				c.y += c.vy;
				c.x += c.vx + Math.sin(tiempo + c.fase) * 0.18;
				if (c.y > alto + 8) { c.y = -8; c.x = Math.random() * ancho; }
				if (c.x < -8) c.x = ancho + 8;
				if (c.x > ancho + 8) c.x = -8;
				copo(c);
			}
			requestAnimationFrame(pintar);
		}

		medir();
		crear();
		pintar();

		var espera;
		window.addEventListener('resize', function () {
			clearTimeout(espera);
			espera = setTimeout(function () { medir(); crear(); }, 220);
		}, { passive: true });

		document.addEventListener('visibilitychange', function () {
			if (document.hidden) {
				vivo = false;
			} else if (!vivo) {
				vivo = true;
				pintar();
			}
		});
	}

	/* ────────────────────────────────────────────────────────────────
	   CABECERA
	   ──────────────────────────────────────────────────────────────── */

	function iniciarCabecera() {
		var cabecera = document.querySelector('.wp-site-blocks > header');
		if (!cabecera) return;
		var pinta = function () {
			cabecera.classList.toggle('jn-scrolled', window.scrollY > 8);
		};
		var medir = function () {
			raiz.style.setProperty('--jn-cab-alto', cabecera.offsetHeight + 'px');
		};
		window.addEventListener('scroll', pinta, { passive: true });
		window.addEventListener('resize', medir, { passive: true });
		medir();
		pinta();
	}

	/* ────────────────────────────────────────────────────────────────
	   APARICIÓN AL DESPLAZAR
	   ──────────────────────────────────────────────────────────────── */

	function iniciarReveal() {
		if (reducido) return;

		var piezas = document.querySelectorAll(
			'.jn-exp > .jn-bloque, .jn-cine, .jn-card, .jn-estado__dato, .jn-nav__arbol'
		);
		if (!piezas.length) return;

		piezas.forEach(function (el) { el.classList.add('jn-reveal'); });

		/* comprobación directa y barata: ningún salto de ancla ni pestaña en
		   segundo plano puede dejar una sección oculta. */
		var pendiente = false;
		var revelar = function () {
			pendiente = false;
			var limite = window.innerHeight * 0.94;
			piezas.forEach(function (el) {
				if (el.classList.contains('jn-visible')) return;
				var caja = el.getBoundingClientRect();
				if (caja.top < limite && caja.bottom > -20) {
					el.classList.add('jn-visible');
				}
			});
		};
		var alDesplazar = function () {
			if (pendiente) return;
			pendiente = true;
			requestAnimationFrame(revelar);
		};

		window.addEventListener('scroll', alDesplazar, { passive: true });
		window.addEventListener('resize', alDesplazar, { passive: true });
		window.addEventListener('load', revelar);
		revelar();
		setTimeout(revelar, 700);
	}

	/* ────────────────────────────────────────────────────────────────
	   ÍNDICE DE EXPERIENCIAS
	   ──────────────────────────────────────────────────────────────── */

	function iniciarAnclas() {
		var nav = document.querySelector('[data-jn-anclas]');
		if (!nav) return;

		var enlaces = nav.querySelectorAll('a[data-ancla]');
		var secciones = [];
		enlaces.forEach(function (a) {
			var sec = document.getElementById(a.getAttribute('data-ancla'));
			if (sec) secciones.push(sec);
		});
		if (!secciones.length) return;

		var marcar = function (id) {
			enlaces.forEach(function (a) {
				var activa = a.getAttribute('data-ancla') === id;
				a.classList.toggle('is-activa', activa);
				if (activa) a.setAttribute('aria-current', 'true');
				else a.removeAttribute('aria-current');
			});
		};

		enlaces.forEach(function (a) {
			a.addEventListener('click', function () {
				marcar(a.getAttribute('data-ancla'));
			});
		});

		/* la sección activa es la última que ha pasado el umbral de lectura;
		   más estable que una banda estrecha cuando se salta con anclas. */
		var pendiente = false;
		var calcular = function () {
			pendiente = false;
			var altoCab = parseInt(getComputedStyle(raiz).getPropertyValue('--jn-cab-alto'), 10) || 64;
			var limite = window.scrollY + altoCab + Math.min(260, window.innerHeight * 0.34);
			var actual = secciones[0].id;
			secciones.forEach(function (sec) {
				var arriba = sec.getBoundingClientRect().top + window.scrollY;
				if (arriba <= limite) actual = sec.id;
			});
			marcar(actual);
		};
		var alDesplazar = function () {
			if (pendiente) return;
			pendiente = true;
			requestAnimationFrame(calcular);
		};
		window.addEventListener('scroll', alDesplazar, { passive: true });
		window.addEventListener('resize', alDesplazar, { passive: true });
		window.addEventListener('load', calcular);
		calcular();
	}

	/* ────────────────────────────────────────────────────────────────
	   INTRO CINEMATOGRÁFICA
	   ──────────────────────────────────────────────────────────────── */

	function iniciarIntro() {
		var intro = document.querySelector('.jn-intro');
		if (!intro) return;

		var clave = intro.getAttribute('data-clave') || 'jn-intro';
		var heroVideo = document.querySelector('.jn-hero-video video');

		try {
			if (sessionStorage.getItem(clave) === '1') {
				intro.parentNode.removeChild(intro);
				return;
			}
		} catch (e) {}

		document.body.classList.add('jn-intro-abierto');
		if (heroVideo) heroVideo.pause();

		var cerrada = false;
		var cerrar = function () {
			if (cerrada) return;
			cerrada = true;
			intro.classList.add('jn-intro--fuera');
			document.body.classList.remove('jn-intro-abierto');
			try { sessionStorage.setItem(clave, '1'); } catch (e) {}
			if (heroVideo) {
				var p = heroVideo.play();
				if (p && p.catch) p.catch(function () {});
			}
			setTimeout(function () {
				if (intro.parentNode) intro.parentNode.removeChild(intro);
			}, 900);
		};

		intro.addEventListener('click', cerrar);
		intro.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' || e.key === 'Enter') cerrar();
		});
		var saltar = intro.querySelector('.jn-intro__saltar');
		if (saltar) {
			saltar.focus({ preventScroll: true });
			saltar.addEventListener('click', function (e) {
				e.stopPropagation();
				cerrar();
			});
		}
	}

	/* ────────────────────────────────────────────────────────────────
	   REPRODUCTORES
	   ──────────────────────────────────────────────────────────────── */

	function tiempo(seg) {
		if (!isFinite(seg) || seg < 0) seg = 0;
		var m = Math.floor(seg / 60);
		var s = Math.floor(seg % 60);
		return m + ':' + (s < 10 ? '0' : '') + s;
	}

	function iniciarReproductores() {
		document.querySelectorAll('[data-jn-cine]').forEach(function (bloque) {
			var video = bloque.querySelector('video');
			if (!video) return;
			/* controls nativos solo como red de seguridad sin JavaScript */
			if (video.hasAttribute('controls')) video.removeAttribute('controls');

			var botonPlay = bloque.querySelector('[data-jn-play]');
			var botonGrande = bloque.querySelector('[data-jn-play-grande]');
			var botonSonido = bloque.querySelector('[data-jn-sonido]');
			var botonPantalla = bloque.querySelector('[data-jn-pantalla]');
			var etiqueta = bloque.querySelector('.jn-cine__tiempo');
			var barra = bloque.querySelector('.jn-cine__barra');
			var relleno = barra ? barra.querySelector('i') : null;
			var marco = bloque.querySelector('.jn-hero-video__marco, .jn-cine__marco');
			var corte = parseInt(bloque.getAttribute('data-jn-corte'), 10) || 0;

			function pintaTiempo() {
				if (!etiqueta) return;
				if (corte) {
					var t = Math.min(video.currentTime || 0, corte);
					etiqueta.textContent = tiempo(t) + ' / ' + tiempo(corte);
				} else {
					var dur = isFinite(video.duration) ? video.duration : 0;
					etiqueta.textContent = tiempo(video.currentTime) + (dur ? ' / ' + tiempo(dur) : '');
				}
				if (relleno && isFinite(video.duration) && video.duration > 0) {
					relleno.style.transform = 'scaleX(' + Math.min(1, video.currentTime / video.duration) + ')';
				}
			}			function pintaBoton() {
				var pausado = video.paused;
				if (botonPlay) {
					botonPlay.textContent = pausado ? '▶' : '❚❚';
					botonPlay.setAttribute('aria-label', pausado ? 'Reproducir' : 'Pausar');
				}
				bloque.classList.toggle('is-playing', !pausado);
			}

			function alternar() {
				if (video.paused) {
					var p = video.play();
					if (p && p.catch) p.catch(function () {});
				} else {
					video.pause();
				}
			}

			if (botonPlay) botonPlay.addEventListener('click', alternar);
			if (botonGrande) {
				botonGrande.addEventListener('click', function (e) {
					e.stopPropagation();
					alternar();
				});
			}
			video.addEventListener('click', function (e) {
				e.stopPropagation();
				alternar();
			});
			video.addEventListener('play', pintaBoton);
			video.addEventListener('pause', pintaBoton);
			video.addEventListener('timeupdate', function () {
				if (corte && video.currentTime >= corte - 0.05) {
					video.currentTime = 0;
					if (!video.paused) {
						var p = video.play();
						if (p && p.catch) p.catch(function () {});
					}
				}
				pintaTiempo();
			});
			video.addEventListener('loadedmetadata', pintaTiempo);
			video.addEventListener('ended', pintaBoton);

			if (botonSonido) {
				botonSonido.addEventListener('click', function () {
					video.muted = !video.muted;
					botonSonido.textContent = video.muted ? '🔇' : '🔊';
					botonSonido.setAttribute('aria-label', video.muted ? 'Activar sonido' : 'Silenciar');
					if (!video.muted) {
						video.volume = 0.85;
						var p = video.play();
						if (p && p.catch) p.catch(function () {});
					}
				});
			}

			if (botonPantalla && marco) {
				botonPantalla.addEventListener('click', function () {
					if (document.fullscreenElement || document.webkitFullscreenElement) {
						(document.exitFullscreen || document.webkitExitFullscreen || function () {}).call(document);
						return;
					}
					var fn = marco.requestFullscreen || marco.webkitRequestFullscreen;
					if (fn) {
						var r = fn.call(marco);
						if (r && r.catch) r.catch(function () {});
					}
				});
			}

			if (barra && !corte) {
				barra.addEventListener('click', function (e) {
					if (!isFinite(video.duration) || !video.duration) return;
					var caja = barra.getBoundingClientRect();
					var x = Math.min(Math.max((e.clientX - caja.left) / caja.width, 0), 1);
					video.currentTime = x * video.duration;
					pintaTiempo();
				});
			}

			pintaBoton();
			pintaTiempo();
		});
	}

	/* ────────────────────────────────────────────────────────────────
	   MAPA DE NODOS
	   ──────────────────────────────────────────────────────────────── */

	function iniciarMapa() {
		var mapa = document.querySelector('[data-jn-mapa]');
		if (!mapa) return;

		var enlaces = {
			tu: [],
			s1: ['tu-s1'],
			s2: ['tu-s1', 's1-s2'],
			s3: ['s1-s2', 's2-s3'],
			destino: ['s3-destino']
		};

		var todos = mapa.querySelectorAll('[data-nodo]');
		var fichas = mapa.querySelectorAll('[data-nodo-vista]');
		var lineas = mapa.querySelectorAll('[data-enlace]');
		var flujos = mapa.querySelectorAll('[data-flujo]');

		function activar(nodo) {
			if (!nodo) return;

			todos.forEach(function (el) {
				var activo = el.getAttribute('data-nodo') === nodo;
				el.classList.toggle('is-activo', activo);
				if (el.tagName === 'BUTTON') el.setAttribute('aria-pressed', activo ? 'true' : 'false');
				else el.setAttribute('aria-pressed', activo ? 'true' : 'false');
			});

			fichas.forEach(function (ficha) {
				ficha.hidden = ficha.getAttribute('data-nodo-vista') !== nodo;
			});

			var activos = enlaces[nodo] || [];
			lineas.forEach(function (linea) {
				linea.classList.toggle('is-on', activos.indexOf(linea.getAttribute('data-enlace')) !== -1);
			});
			flujos.forEach(function (flujo) {
				flujo.classList.toggle('is-on', activos.indexOf(flujo.getAttribute('data-flujo')) !== -1);
			});
		}

		mapa.addEventListener('click', function (e) {
			var objetivo = e.target.closest ? e.target.closest('[data-nodo]') : null;
			if (!objetivo || !mapa.contains(objetivo)) return;
			activar(objetivo.getAttribute('data-nodo'));
		});

		mapa.addEventListener('keydown', function (e) {
			if (e.key !== 'Enter' && e.key !== ' ' && e.key !== 'Spacebar') return;
			var objetivo = e.target.closest ? e.target.closest('[data-nodo]') : null;
			if (!objetivo) return;
			e.preventDefault();
			activar(objetivo.getAttribute('data-nodo'));
		});

		activar('tu');
	}

	/* ────────────────────────────────────────────────────────────────
	   VIAJE DEL PAQUETE
	   ──────────────────────────────────────────────────────────────── */

	function iniciarViaje() {
		var viaje = document.querySelector('[data-jn-viaje]');
		if (!viaje) return;

		var play = viaje.querySelector('[data-jn-viaje-play]');
		var pasoBtn = viaje.querySelector('[data-jn-viaje-paso]');
		var reset = viaje.querySelector('[data-jn-viaje-reset]');
		var estado = viaje.querySelector('[data-jn-viaje-estado]');
		var paquete = viaje.querySelector('[data-jn-paquete]');
		var barra = viaje.querySelector('.jn-viaje__barra');
		var relleno = viaje.querySelector('[data-jn-viaje-barra]');
		var paradas = viaje.querySelectorAll('[data-parada]');
		var etapas = viaje.querySelectorAll('[data-etapa]');

		var paso = 0;
		var timer = null;

		function pinta() {
			if (paquete) paquete.style.setProperty('--p', (paso / 4) * 100);
			if (relleno) relleno.style.transform = 'scaleX(' + (paso / 4) + ')';
			if (barra) barra.setAttribute('aria-valuenow', Math.round((paso / 4) * 100));

			paradas.forEach(function (parada) {
				var i = parseInt(parada.getAttribute('data-parada'), 10);
				parada.classList.toggle('is-hecho', i < paso);
				parada.classList.toggle('is-actual', i === paso);
			});

			etapas.forEach(function (etapa) {
				etapa.hidden = parseInt(etapa.getAttribute('data-etapa'), 10) !== paso;
			});
		}

		function pararTimer() {
			if (timer) {
				clearTimeout(timer);
				timer = null;
			}
		}

		function marcha() {
			pararTimer();
			viaje.classList.add('is-marcha');
			if (estado) {
				estado.textContent = 'en marcha';
				estado.classList.add('is-marcha');
			}
			if (play) play.textContent = 'pausar';
			programa();
		}

		function programa() {
			pararTimer();
			timer = setTimeout(function () {
				if (paso < 4) {
					paso++;
					pinta();
					if (paso < 4) {
						programa();
					} else {
						completar();
					}
				}
			}, 2100);
		}

		function completar() {
			pararTimer();
			viaje.classList.remove('is-marcha');
			if (estado) {
				estado.textContent = 'completado';
				estado.classList.remove('is-marcha');
			}
			if (play) play.textContent = 'repetir viaje';
		}

		function pausar() {
			pararTimer();
			viaje.classList.remove('is-marcha');
			if (estado) {
				estado.textContent = 'en pausa';
				estado.classList.remove('is-marcha');
			}
			if (play) play.textContent = 'continuar';
		}

		function reiniciar() {
			pararTimer();
			paso = 0;
			viaje.classList.remove('is-marcha');
			if (estado) {
				estado.textContent = 'en espera';
				estado.classList.remove('is-marcha');
			}
			if (play) play.textContent = 'iniciar viaje';
			pinta();
		}

		if (play) {
			play.addEventListener('click', function () {
				if (timer) {
					pausar();
					return;
				}
				if (paso >= 4) {
					paso = 0;
					pinta();
				}
				marcha();
			});
		}

		if (reset) reset.addEventListener('click', reiniciar);

		if (pasoBtn) {
			pasoBtn.addEventListener('click', function () {
				pararTimer();
				viaje.classList.remove('is-marcha');
				if (paso < 4) paso++;
				else paso = 0;
				pinta();
				var nombres = ['origen', 'salto 1', 'salto 2', 'salto 3', 'destino'];
				if (estado) {
					estado.textContent = paso === 4 ? 'completado' : 'paso ' + paso + ' · ' + nombres[paso];
					estado.classList.remove('is-marcha');
				}
				if (play) play.textContent = paso === 4 ? 'repetir viaje' : 'continuar';
			});
		}

		pinta();
	}

	/* ────────────────────────────────────────────────────────────────
	   CIFRADO POR SALTOS
	   ──────────────────────────────────────────────────────────────── */

	function iniciarCifrado() {
		var cif = document.querySelector('[data-jn-cif]');
		if (!cif) return;

		var botones = cif.querySelectorAll('[data-vista-btn]');
		var fichas = cif.querySelectorAll('[data-vista]');

		function ver(vista) {
			cif.setAttribute('data-vista', vista);
			botones.forEach(function (btn) {
				var activa = btn.getAttribute('data-vista-btn') === vista;
				btn.setAttribute('aria-selected', activa ? 'true' : 'false');
				btn.tabIndex = activa ? 0 : -1;
			});
			fichas.forEach(function (ficha) {
				ficha.hidden = ficha.getAttribute('data-vista') !== vista;
			});
		}

		botones.forEach(function (btn) {
			btn.addEventListener('click', function () {
				ver(btn.getAttribute('data-vista-btn'));
			});
			btn.addEventListener('keydown', function (e) {
				if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
				e.preventDefault();
				var lista = Array.prototype.slice.call(botones);
				var i = lista.indexOf(btn);
				var siguiente = e.key === 'ArrowRight' ? (i + 1) % lista.length : (i - 1 + lista.length) % lista.length;
				lista[siguiente].focus();
				ver(lista[siguiente].getAttribute('data-vista-btn'));
			});
		});
	}

	/* ────────────────────────────────────────────────────────────────
	   COMPARADOR
	   ──────────────────────────────────────────────────────────────── */

	function iniciarComparador() {
		var comp = document.querySelector('[data-jn-comp]');
		if (!comp) return;

		comp.querySelectorAll('[data-jn-comp-btn]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var modo = btn.getAttribute('data-jn-comp-btn');
				comp.setAttribute('data-activo', modo);
				comp.querySelectorAll('[data-jn-comp-btn]').forEach(function (otro) {
					otro.setAttribute('aria-pressed', otro === btn ? 'true' : 'false');
				});
			});
		});
	}

	/* ────────────────────────────────────────────────────────────────
	   TERMINAL EDUCATIVA
	   ──────────────────────────────────────────────────────────────── */

	function iniciarTerminal() {
		var term = document.querySelector('[data-jn-term]');
		if (!term) return;

		var salida = term.querySelector('[data-jn-term-salida]');
		var form = term.querySelector('[data-jn-term-form]');
		var input = term.querySelector('[data-jn-term-input]');
		if (!salida || !form || !input) return;

		var historial = [];
		var indice = 0;

		function linea(texto, clase) {
			var p = document.createElement('p');
			if (clase) p.className = 'jn-term__' + clase;
			p.textContent = texto;
			salida.appendChild(p);
			while (salida.children.length > 48) salida.removeChild(salida.firstChild);
			salida.scrollTop = salida.scrollHeight;
		}

		function ayuda() {
			linea('Comandos disponibles (ejemplos, nada se ejecuta):', 'ok');
			linea('  help                      esta ayuda', 'atenuado');
			linea('  curl --socks5-hostname    petición a través de SOCKS5', 'atenuado');
			linea('  ssh -D                    túnel SOCKS local por SSH', 'atenuado');
			linea('  jumpernet estado          resumen de la configuración', 'atenuado');
			linea('  whoami                    quién hay en esta consola', 'atenuado');
			linea('  clear                     limpiar la pantalla', 'atenuado');
		}

		function ejecutar(bruto) {
			var texto = bruto.trim();
			if (!texto) return;
			linea('$ ' + texto, 'eco');
			historial.push(texto);
			indice = historial.length;

			var cmd = texto.toLowerCase();

			if (cmd === 'help' || cmd === 'ayuda' || cmd === '?') {
				ayuda();
				return;
			}

			if (cmd === 'clear' || cmd === 'limpiar') {
				salida.replaceChildren();
				salida.scrollTop = 0;
				return;
			}

			if (cmd === 'whoami' || cmd === 'quien') {
				linea('invitado · consola del navegador', 'ok');
				linea('No hay sesión, ni red, ni permisos: esto es una demostración.', 'atenuado');
				return;
			}

			if (cmd.indexOf('curl') === 0) {
				linea('[simulación] curl --socks5-hostname 127.0.0.1:1080 https://ejemplo.test', 'ok');
				linea('La aplicación entregaría la petición al proxy local.', 'atenuado');
				linea('El proxy resolvería el nombre y abriría el primer salto.', 'atenuado');
				linea('No se ha enviado ninguna petición real.', 'atenuado');
				return;
			}

			if (cmd.indexOf('ssh') === 0) {
				linea('[simulación] ssh -D 1080 usuario@salto1.ejemplo.test', 'ok');
				linea('Se abriría un SOCKS local en 127.0.0.1:1080.', 'atenuado');
				linea('El tráfico del navegador viajaría por ese túnel.', 'atenuado');
				linea('Ejemplo ilustrativo: no se abre ninguna conexión.', 'atenuado');
				return;
			}

			if (cmd.indexOf('jumpernet') === 0) {
				linea('configuración educativa', 'ok');
				linea('  saltos: 3 (modelo de la documentación)', 'atenuado');
				linea('  cifrado: JENC por capas', 'atenuado');
				linea('  versión del tema: ' + (JN.version || '2.1.0'), 'atenuado');
				linea('  estado de nodos remotos: no monitorizado', 'atenuado');
				return;
			}

			linea('orden no reconocida: ' + texto, 'error');
			linea('Escribe «help» para ver los comandos disponibles.', 'atenuado');
		}

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			ejecutar(input.value);
			input.value = '';
		});

		term.querySelectorAll('[data-jn-term-chip]').forEach(function (chip) {
			chip.addEventListener('click', function () {
				ejecutar(chip.getAttribute('data-jn-term-chip') || '');
				input.focus({ preventScroll: true });
			});
		});

		input.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowUp') {
				e.preventDefault();
				if (!historial.length) return;
				indice = Math.max(0, indice - 1);
				input.value = historial[indice] || '';
			} else if (e.key === 'ArrowDown') {
				e.preventDefault();
				indice = Math.min(historial.length, indice + 1);
				input.value = historial[indice] || '';
			}
		});

		term.addEventListener('click', function (e) {
			if (e.target.closest('button') || e.target === input) return;
			if (window.getSelection && String(window.getSelection()).length) return;
			input.focus({ preventScroll: true });
		});
	}

	/* ────────────────────────────────────────────────────────────────
	   GLOSARIO
	   ──────────────────────────────────────────────────────────────── */

	function iniciarGlosario() {
		var glos = document.querySelector('[data-jn-glos]');
		if (!glos) return;

		var input = glos.querySelector('[data-jn-glos-buscar]');
		var cuenta = glos.querySelector('[data-jn-glos-cuenta]');
		var items = glos.querySelectorAll('.jn-glos__item');
		if (!input) return;

		function filtrar() {
			var q = input.value.trim().toLowerCase();
			var visibles = 0;
			items.forEach(function (item) {
				var coincide = !q || item.textContent.toLowerCase().indexOf(q) !== -1;
				item.hidden = !coincide;
				if (coincide) visibles++;
			});
			if (cuenta) {
				cuenta.textContent = visibles === 1 ? '1 término' : visibles + ' términos';
			}
		}

		input.addEventListener('input', filtrar);
		filtrar();
	}

	/* ────────────────────────────────────────────────────────────────
	   RECORRIDO GUIADO
	   ──────────────────────────────────────────────────────────────── */

	function iniciarTour() {
		var ini = document.querySelector('[data-jn-tour-ini]');
		var caja = document.querySelector('[data-jn-tour]');
		if (!ini || !caja) return;

		var txt = caja.querySelector('[data-jn-tour-txt]');
		var pasoEl = caja.querySelector('[data-jn-tour-paso]');
		var next = caja.querySelector('[data-jn-tour-next]');
		var fin = caja.querySelector('[data-jn-tour-fin]');

		var pasos = [
			{ sel: '.jn-hero', texto: 'La portada: título, cifras reales del sitio y el corte de 30 s del documental.' },
			{ sel: '#el-viaje', texto: 'La película completa: siete minutos dentro del circuito, de principio a fin.' },
			{ sel: '#red', texto: 'El mapa: toca cada nodo para ver qué información tiene y cuál no.' },
			{ sel: '#viaje', texto: 'El simulador: inicia el viaje y sigue el paquete por los tres saltos.' },
			{ sel: '#cifrado', texto: 'El cifrado por capas: cambia el punto de vista y compara lo que ve cada salto.' },
			{ sel: '#terminal', texto: 'La terminal educativa: ejemplos de comandos SOCKS5 sin ejecutar nada.' }
		];

		var actual = -1;
		var anterior = null;

		function limpiar() {
			if (anterior) anterior.classList.remove('is-tour');
			anterior = null;
		}

		function mostrar(i) {
			limpiar();
			actual = i;
			var paso = pasos[i];
			var objetivo = paso ? document.querySelector(paso.sel) : null;

			if (!paso || !objetivo) {
				terminar();
				return;
			}

			objetivo.classList.add('is-tour');
			anterior = objetivo;
			objetivo.scrollIntoView({ behavior: reducido ? 'auto' : 'smooth', block: 'start' });

			if (pasoEl) pasoEl.textContent = (i + 1) + ' / ' + pasos.length;
			if (txt) txt.textContent = paso.texto;
			if (next) next.textContent = i === pasos.length - 1 ? 'terminar' : 'siguiente';
		}

		function empezar() {
			caja.hidden = false;
			document.body.classList.add('jn-tour-abierto');
			mostrar(0);
			if (next) next.focus({ preventScroll: true });
		}

		function terminar() {
			caja.hidden = true;
			document.body.classList.remove('jn-tour-abierto');
			limpiar();
			actual = -1;
			ini.focus({ preventScroll: true });
		}

		ini.addEventListener('click', empezar);
		if (next) {
			next.addEventListener('click', function () {
				if (actual >= pasos.length - 1) {
					terminar();
					return;
				}
				mostrar(actual + 1);
			});
		}
		if (fin) fin.addEventListener('click', terminar);

		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && !caja.hidden) terminar();
		});
	}

	/* ────────────────────────────────────────────────────────────────
	   ARRANQUE
	   ──────────────────────────────────────────────────────────────── */

	function arrancar() {
		iniciarTema();
		iniciarCabecera();
		iniciarReproductores();
		iniciarMapa();
		iniciarViaje();
		iniciarCifrado();
		iniciarComparador();
		iniciarTerminal();
		iniciarGlosario();
		iniciarTour();
		iniciarAnclas();
		iniciarReveal();
		iniciarRed();
		iniciarNieve();
		iniciarIntro();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', arrancar);
	} else {
		arrancar();
	}
})();
