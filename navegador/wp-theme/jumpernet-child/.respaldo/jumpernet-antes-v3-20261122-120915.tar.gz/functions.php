<?php
/*
 * JumperNET Docs — tema hijo de Twenty Twenty-Four.
 *
 * v2.1.0
 *  · Portada editorial: corte de 30 s junto al título y película completa.
 *  · Sistema visual claro/oscuro conmutable, fondo de red vivo y Navidad sutil.
 *  · Experiencias educativas: mapa de nodos, viaje del paquete, cifrado por
 *    saltos, comparador, estado real del sitio, terminal, glosario y FAQ.
 *  · Navegación entre experiencias con sección activa y cabecera compacta.
 *  · Panel propio al iniciar sesión: widget rápido, menú JumperNET, accesos
 *    en la barra de administración y login con la marca.
 */

if (!defined('JN_VERSION')) {
	define('JN_VERSION', '2.1.0');
}

/* temporada navideña: del 15 de noviembre al 6 de enero */
function jn_es_navidad() {
	$m = (int) date_i18n('n');
	$d = (int) date_i18n('j');
	return ($m === 11 && $d >= 15) || $m === 12 || ($m === 1 && $d <= 6);
}

function jn_saludo_navidad() {
	$m = (int) date_i18n('n');
	$d = (int) date_i18n('j');
	if ($m === 12 && $d === 24) return 'Feliz Nochebuena';
	if ($m === 12 && $d === 25) return 'Feliz Navidad';
	if ($m === 12 && $d === 31) return 'Feliz Nochevieja';
	if ($m === 1 && $d === 1) return 'Feliz Año Nuevo';
	return 'Felices fiestas';
}

add_filter('body_class', function ($clases) {
	if (jn_es_navidad()) {
		$clases[] = 'jn-navidad';
	}
	return $clases;
});

/* el tema se fija antes de pintar para que no haya destello */
add_action('wp_head', function () {
	?>
	<script>
	(function () {
		var t = 'claro';
		try {
			var g = localStorage.getItem('jn-tema');
			if (g === 'claro' || g === 'oscuro') {
				t = g;
			} else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
				t = 'oscuro';
			}
		} catch (e) {}
		document.documentElement.setAttribute('data-jn-tema', t);
		document.documentElement.style.colorScheme = t;
	})();
	</script>
	<?php
}, 1);

/* ─── utilidades de assets ─── */
function jn_asset_uri($ruta = '') {
	return get_stylesheet_directory_uri() . '/assets/' . ltrim($ruta, '/');
}
function jn_asset_path($ruta = '') {
	return get_stylesheet_directory() . '/assets/' . ltrim($ruta, '/');
}
function jn_hay_video() {
	return file_exists(jn_asset_path('el-viaje.mp4'));
}
function jn_poster_video() {
	$poster = jn_asset_uri('el-viaje-poster.jpg');
	return file_exists(jn_asset_path('el-viaje-poster.jpg')) ? $poster : '';
}

add_action('wp_enqueue_scripts', function () {
	if (wp_get_theme()->parent()) {
		wp_enqueue_style(
			'twentytwentyfour-style',
			get_template_directory_uri() . '/style.css',
			array(),
			wp_get_theme()->parent()->get('Version')
		);
	}
	wp_enqueue_style('jumpernet-child', get_stylesheet_uri(), array('twentytwentyfour-style'), JN_VERSION);

	wp_enqueue_script('jumpernet-sitio', jn_asset_uri('jn-sitio.js'), array(), JN_VERSION, true);
	wp_add_inline_script(
		'jumpernet-sitio',
		'window.JN = ' . wp_json_encode(array(
			'video'    => jn_hay_video() ? jn_asset_uri('el-viaje.mp4') : '',
			'portada'  => is_front_page(),
			'navidad'  => jn_es_navidad(),
			'version'  => JN_VERSION,
			'corte'    => 30,
		)) . ';',
		'before'
	);
});

/* ─── login con la marca ─── */
add_filter('login_headerurl', function () { return home_url('/'); });
add_filter('login_headertext', function () { return 'JumperNET'; });

add_action('login_enqueue_scripts', function () {
	?>
	<style>
		body.login{
			background:#07050b !important;
			background-image:
				radial-gradient(900px 460px at 62% -12%, rgba(255,90,54,.22), transparent 62%),
				radial-gradient(760px 420px at -4% 104%, rgba(139,123,255,.20), transparent 64%),
				linear-gradient(rgba(255,255,255,.025) 1px, transparent 1px),
				linear-gradient(90deg, rgba(255,255,255,.025) 1px, transparent 1px) !important;
			background-size:auto,auto,48px 48px,48px 48px !important;
		}
		#login h1{display:none}
		#login::before{
			content:"↯  JumperNET";
			display:block;text-align:center;
			font-family:ui-monospace,Consolas,monospace;font-weight:800;
			font-size:24px;letter-spacing:.01em;margin-bottom:20px;
			background:linear-gradient(100deg,#ffd0c0,#ff7a55 42%,#b3a4ff);
			-webkit-background-clip:text;background-clip:text;color:transparent;
			filter:drop-shadow(0 10px 26px rgba(255,90,54,.35));
		}
		#loginform::before{
			content:"documentación interna · acceso";
			display:block;margin:0 0 16px;
			font-family:ui-monospace,Consolas,monospace;font-size:10.5px;
			letter-spacing:.18em;text-transform:uppercase;color:#8f8598;
		}
		#login form,#loginform{
			background:#12101a !important;border:1px solid #2b2436 !important;border-radius:18px;
			box-shadow:0 28px 70px -40px #000,0 0 0 1px rgba(255,255,255,.02) inset !important;padding:26px !important
		}
		#login label{color:#b7acb8;font-size:12.5px}
		#login input[type=text],#login input[type=password]{
			background:#0b0910 !important;color:#f7f1e8 !important;
			border:1px solid #2b2436 !important;border-radius:10px !important;padding:10px 11px !important
		}
		#login input:focus{border-color:#ff5a36 !important;box-shadow:0 0 0 3px rgba(255,90,54,.15) !important}
		#wp-submit{
			background:linear-gradient(135deg,#ffb59a,#ff5a36 58%,#e2491f) !important;border-color:transparent !important;border-radius:10px !important;
			color:#241007 !important;font-weight:700;padding:9px 18px !important;
			box-shadow:0 16px 34px -18px rgba(255,90,54,.9)
		}
		#wp-submit:hover{background:linear-gradient(135deg,#ffc9b4,#ff6a3d) !important}
		#nav,#backtoblog a{color:#9a90a2 !important}
		#nav a:hover,#backtoblog a:hover{color:#ffb09a !important}
		.jn-login-volver{text-align:center;margin:18px 0 0;font-family:ui-monospace,Consolas,monospace;font-size:11px;letter-spacing:.08em}
		.jn-login-volver a{color:#ffb09a !important;text-decoration:none}
		.jn-login-volver a:hover{color:#ffd0c0 !important}
	</style>
	<?php
});

add_action('login_footer', function () {
	echo '<p class="jn-login-volver"><a href="' . esc_url(home_url('/')) . '">← volver a la web</a></p>';
});

/* ─── portada cinematográfica ─── */
function jn_insertar_en_hero($html, $bloque) {
	$pos = strpos($html, 'jn-hero');
	if ($pos === false) {
		return $html;
	}
	$fin = strpos($html, '>', $pos);
	if ($fin === false) {
		return $html;
	}
	return substr($html, 0, $fin + 1) . $bloque . substr($html, $fin + 1);
}

function jn_insertar_tras_hero($html, $bloque) {
	$pos = strpos($html, 'jn-hero');
	if ($pos === false) {
		return $bloque . $html;
	}
	$ini = strrpos(substr($html, 0, $pos), '<div');
	if ($ini === false) {
		return $bloque . $html;
	}
	$i = $ini;
	$prof = 0;
	$largo = strlen($html);
	while ($i < $largo) {
		$abre = strpos($html, '<div', $i);
		$cierra = strpos($html, '</div', $i);
		if ($cierra === false) {
			return $bloque . $html;
		}
		if ($abre !== false && $abre < $cierra) {
			$prof++;
			$i = $abre + 4;
		} else {
			$prof--;
			$fin = $cierra + 6;
			$i = $fin;
			if ($prof === 0) {
				return substr($html, 0, $fin) . $bloque . substr($html, $fin);
			}
		}
	}
	return $bloque . $html;
}

function jn_bloque_hero_video() {
	$url = esc_url(jn_asset_uri('el-viaje.mp4'));
	$poster = jn_poster_video();
	return '<figure class="jn-hero-video" data-jn-cine data-jn-corte="30">'
		. '<div class="jn-hero-video__marco">'
		. '<video class="jn-cine__video" src="' . $url . '"' . ($poster ? ' poster="' . esc_url($poster) . '"' : '') . ' autoplay muted loop playsinline preload="metadata" aria-label="Corte de 30 segundos del documental El Viaje"></video>'
		. '<span class="jn-hero-video__tag">▷ así viaja tu tráfico · 30 s</span>'
		. '<div class="jn-hero-video__pie">'
		. '<button type="button" data-jn-play aria-label="Pausar">❚❚</button>'
		. '<button type="button" data-jn-sonido aria-label="Activar sonido">🔇</button>'
		. '<button type="button" data-jn-pantalla aria-label="Pantalla completa">⛶</button>'
		. '<span class="jn-cine__tiempo">0:00</span>'
		. '</div></div>'
		. '<figcaption>corte de 30 s · la película completa, abajo</figcaption>'
		. '</figure>';
}

function jn_bloque_pelicula() {
	$url = esc_url(jn_asset_uri('el-viaje.mp4'));
	$poster = jn_poster_video();
	return '<section class="jn-cine" id="el-viaje" data-jn-cine>'
		. '<div class="jn-cine__cab">'
		. '<span class="jn-cine__tag">▷ el viaje · 7 min</span>'
		. '<h2>El viaje completo, <em>de principio a fin</em></h2>'
		. '<p>Siete minutos dentro de la red: cómo se encienden los nodos, cómo salta el paquete y qué ve cada salto.</p>'
		. '</div>'
		. '<div class="jn-cine__marco">'
		. '<video class="jn-cine__video" src="' . $url . '"' . ($poster ? ' poster="' . esc_url($poster) . '"' : '') . ' controls muted playsinline preload="metadata" aria-label="Documental El Viaje, siete minutos"></video>'
		. '<div class="jn-cine__velo" aria-hidden="true"></div>'
		. '<button type="button" class="jn-cine__play" data-jn-play-grande aria-label="Reproducir el documental"><span aria-hidden="true">▶</span><small>ver el documental · 7 min</small></button>'
		. '<noscript><style>.jn-cine__play,.jn-cine__controles{display:none !important}</style></noscript>'
		. '<div class="jn-cine__controles">'
		. '<button type="button" data-jn-play aria-label="Reproducir">▶</button>'
		. '<button type="button" data-jn-sonido aria-label="Activar sonido">🔇</button>'
		. '<button type="button" data-jn-pantalla aria-label="Pantalla completa">⛶</button>'
		. '<div class="jn-cine__barra" role="presentation"><i></i></div>'
		. '<span class="jn-cine__tiempo">0:00</span>'
		. '</div></div></section>';
}

add_filter('the_content', function ($contenido) {
	static $hecho = false;
	if ($hecho || is_admin() || !is_front_page() || !jn_hay_video()) {
		return $contenido;
	}
	if (get_the_ID() !== get_queried_object_id()) {
		return $contenido;
	}
	$hecho = true;
	$contenido = jn_insertar_en_hero($contenido, jn_bloque_hero_video());
	return jn_insertar_tras_hero($contenido, jn_bloque_pelicula() . jn_bloque_experiencia());
}, 8);

/* ─── intro a pantalla completa (una vez por sesión) ─── */
add_action('wp_footer', function () {
	if (!is_front_page() || !jn_hay_video()) {
		return;
	}
	?>
	<div class="jn-intro" id="jn-intro" data-clave="jn-intro-v12" role="dialog" aria-modal="true" aria-label="Presentación de JumperNET">
		<video class="jn-intro__video" src="<?php echo esc_url(jn_asset_uri('el-viaje.mp4')); ?>" muted loop playsinline preload="metadata"></video>
		<div class="jn-intro__velo" aria-hidden="true"></div>
		<div class="jn-intro__marca">
			<span class="jn-intro__marca-logo" aria-hidden="true">↯</span>
			<span class="jn-intro__kicker">red educativa · el viaje</span>
			<h2 class="jn-intro__titulo">Jumper<em>NET</em></h2>
			<p class="jn-intro__sub">tu conexión <em>no va sola</em></p>
			<button type="button" class="jn-intro__saltar">entrar →</button>
			<span class="jn-intro__pista">o pulsa en cualquier sitio</span>
		</div>
		<div class="jn-intro__linea" aria-hidden="true"><i></i></div>
	</div>
	<noscript><style>.jn-intro{display:none!important}</style></noscript>
	<?php
}, 5);

/* ─── lectura y código: progreso + copiar ─── */
add_action('wp_footer', function () {
	if (!is_singular()) return;
	?>
	<div id="jn-progreso" aria-hidden="true"></div>
	<script>
	(function () {
		var barra = document.getElementById('jn-progreso');
		function pinta() {
			var h = document.documentElement;
			var max = h.scrollHeight - h.clientHeight;
			if (barra) barra.style.transform = 'scaleX(' + (max > 0 ? Math.min(1, h.scrollTop / max) : 0) + ')';
		}
		addEventListener('scroll', pinta, { passive: true });
		pinta();

		document.querySelectorAll('.entry-content pre').forEach(function (pre) {
			var boton = document.createElement('button');
			boton.type = 'button';
			boton.className = 'jn-copiar';
			boton.textContent = 'copiar';
			boton.setAttribute('aria-label', 'Copiar el bloque de código');
			boton.addEventListener('click', function () {
				var code = pre.querySelector('code');
				var texto = (code || pre).innerText;
				navigator.clipboard.writeText(texto).then(function () {
					boton.textContent = 'copiado ✓';
					boton.classList.add('hecho');
					setTimeout(function () { boton.textContent = 'copiar'; boton.classList.remove('hecho'); }, 1800);
				});
			});
			pre.appendChild(boton);
		});
	})();
	</script>
	<?php
});

/* ─── caja de serie al final de los artículos ─── */
add_filter('the_content', function ($contenido) {
	if (is_singular('post') && in_the_loop() && is_main_query()) {
		$articulos = array(
			'que-es-jumpernet'           => 'Qué es JumperNET y por qué existe',
			'arquitectura-completa'      => 'Arquitectura completa de la red',
			'seguridad'                  => 'Seguridad',
			'cifrado-de-los-saltos-jenc' => 'El cifrado de los saltos (JENC)',
			'guia-primeros-pasos'        => 'Guía: primeros pasos',
			'navegador-jumpernet'        => 'El navegador JumperNET',
			'extension-del-navegador'    => 'La extensión del navegador',
			'problemas-y-soluciones'     => 'Problemas y soluciones',
			'referencia-api'             => 'Referencia de la API',
			'despliegue-y-operacion'     => 'Despliegue y operación',
		);
		$items = '';
		foreach ($articulos as $slug => $titulo) {
			$items .= '<li><a href="/docs/' . $slug . '/">' . $titulo . '</a></li>';
		}
		$caja = '<aside class="jn-serie"><h2>Índice de la documentación</h2><ol>' . $items . '</ol>'
		      . '<a class="jn-volver" href="/docs/">⌂ volver al índice general</a></aside>';
		return $contenido . $caja;
	}
	return $contenido;
}, 20);

/* ═══════════════════════════════════════════════════════════════════
   EXPERIENCIAS DE PORTADA
   Se inyectan tras la película. Todo es educativo: no se abre ninguna
   conexión, no se ejecuta ningún comando y no se muestran métricas falsas.
   ═══════════════════════════════════════════════════════════════════ */

function jn_bloque_experiencia() {
	$post   = wp_count_posts('post');
	$page   = wp_count_posts('page');
	$datos  = array(
		'{{POSTS}}'    => esc_html((string) (isset($post->publish) ? (int) $post->publish : 0)),
		'{{PAGES}}'    => esc_html((string) (isset($page->publish) ? (int) $page->publish : 0)),
		'{{MEDIA}}'    => esc_html((string) jn_contar_adjuntos()),
		'{{COMMENTS}}' => esc_html((string) jn_contar_comentarios()),
		'{{TEMA}}'     => esc_html(JN_VERSION),
		'{{FECHA}}'    => esc_html(date_i18n('j M Y · H:i')),
		'{{VIDEO}}'    => jn_hay_video() ? 'disponible' : 'no encontrado',
		'{{SALUDO}}'   => esc_html(jn_saludo_navidad()),
		'{{DOCS}}'     => esc_url(home_url('/docs/')),
		'{{GUIA}}'     => esc_url(home_url('/docs/guia-primeros-pasos/')),
	);

	$html = <<<'HTML'
<div class="jn-exp" id="experiencia">

<nav class="jn-anclas" data-jn-anclas aria-label="Secciones de la experiencia">
	<span class="jn-anclas__eti">explorar</span>
	<div class="jn-anclas__lista">
		<a href="#red" data-ancla="red"><b>01</b> mapa</a>
		<a href="#viaje" data-ancla="viaje"><b>02</b> simulador</a>
		<a href="#cifrado" data-ancla="cifrado"><b>03</b> cifrado</a>
		<a href="#comparar" data-ancla="comparar"><b>04</b> comparador</a>
		<a href="#estado" data-ancla="estado"><b>05</b> estado</a>
		<a href="#terminal" data-ancla="terminal"><b>06</b> terminal</a>
		<a href="#glosario" data-ancla="glosario"><b>07</b> glosario</a>
		<a href="#preguntas" data-ancla="preguntas"><b>08</b> preguntas</a>
		<a href="#bajo-el-capo" data-ancla="bajo-el-capo"><b>09</b> arquitectura</a>
		<a href="#navidad" data-ancla="navidad"><b>10</b> navidad</a>
	</div>
</nav>

<section class="jn-bloque" id="red" aria-labelledby="red-tit">
	<header class="jn-bloque__cab">
		<span class="jn-kicker"><b>01</b> mapa de la red</span>
		<h2 class="jn-bloque__tit" id="red-tit">La red, <em>de un vistazo</em></h2>
		<p class="jn-bloque__intro">Cinco piezas, un circuito. Toca un nodo para ver qué papel juega y qué información tiene —y cuál no— en cada salto.</p>
	</header>
	<div class="jn-mapa" data-jn-mapa>
		<div class="jn-mapa__lienzo">
			<svg class="jn-mapa__svg" viewBox="0 0 760 380" role="group" aria-label="Circuito educativo de tres saltos">
				<g class="jn-mapa__trama" aria-hidden="true">
					<path d="M10 60 Q 190 130 370 70 T 750 100"/>
					<path d="M10 330 Q 190 260 370 320 T 750 290"/>
					<circle cx="40" cy="110" r="3"/><circle cx="700" cy="320" r="3"/>
					<circle cx="360" cy="40" r="3"/><circle cx="420" cy="345" r="3"/>
				</g>
				<g class="jn-mapa__enlaces" aria-hidden="true">
					<path data-enlace="tu-s1" d="M60 210 L225 100"/>
					<path data-enlace="s1-s2" d="M225 100 L390 245"/>
					<path data-enlace="s2-s3" d="M390 245 L555 120"/>
					<path data-enlace="s3-destino" d="M555 120 L690 225"/>
				</g>
				<g class="jn-mapa__flujos" aria-hidden="true">
					<path data-flujo="tu-s1" d="M60 210 L225 100"/>
					<path data-flujo="s1-s2" d="M225 100 L390 245"/>
					<path data-flujo="s2-s3" d="M390 245 L555 120"/>
					<path data-flujo="s3-destino" d="M555 120 L690 225"/>
				</g>
				<g class="jn-mapa__nodo" data-nodo="tu" tabindex="0" role="button" aria-label="Tú, el origen">
					<circle class="jn-mapa__halo" cx="60" cy="210" r="30"/>
					<circle class="jn-mapa__punto" cx="60" cy="210" r="13"/>
					<text x="60" y="258">tú</text>
				</g>
				<g class="jn-mapa__nodo" data-nodo="s1" tabindex="0" role="button" aria-label="Salto 1">
					<circle class="jn-mapa__halo" cx="225" cy="100" r="30"/>
					<circle class="jn-mapa__punto" cx="225" cy="100" r="13"/>
					<text x="225" y="66">salto 1</text>
				</g>
				<g class="jn-mapa__nodo" data-nodo="s2" tabindex="0" role="button" aria-label="Salto 2">
					<circle class="jn-mapa__halo" cx="390" cy="245" r="30"/>
					<circle class="jn-mapa__punto" cx="390" cy="245" r="13"/>
					<text x="390" y="294">salto 2</text>
				</g>
				<g class="jn-mapa__nodo" data-nodo="s3" tabindex="0" role="button" aria-label="Salto 3">
					<circle class="jn-mapa__halo" cx="555" cy="120" r="30"/>
					<circle class="jn-mapa__punto" cx="555" cy="120" r="13"/>
					<text x="555" y="86">salto 3</text>
				</g>
				<g class="jn-mapa__nodo" data-nodo="destino" tabindex="0" role="button" aria-label="Destino">
					<circle class="jn-mapa__halo" cx="690" cy="225" r="30"/>
					<circle class="jn-mapa__punto" cx="690" cy="225" r="13"/>
					<text x="690" y="274">destino</text>
				</g>
			</svg>
		</div>
		<div class="jn-mapa__lista" role="group" aria-label="Nodos del circuito">
			<button type="button" data-nodo="tu" aria-pressed="true">tú · origen</button>
			<button type="button" data-nodo="s1" aria-pressed="false">salto 1</button>
			<button type="button" data-nodo="s2" aria-pressed="false">salto 2</button>
			<button type="button" data-nodo="s3" aria-pressed="false">salto 3</button>
			<button type="button" data-nodo="destino" aria-pressed="false">destino</button>
		</div>
		<aside class="jn-ficha" data-jn-ficha aria-live="polite">
			<div class="jn-ficha__vista" data-nodo-vista="tu">
				<span class="jn-ficha__etiqueta">nodo · origen</span>
				<h3>Tú</h3>
				<p>Aquí empieza todo: tu navegador elige el destino y entrega la petición al primer salto.</p>
				<dl class="jn-ficha__datos">
					<div><dt>ve</dt><dd>el destino final; el contenido antes de cifrarse</dd></div>
					<div><dt>no ve</dt><dd>qué camino recorrerá por dentro</dd></div>
				</dl>
			</div>
			<div class="jn-ficha__vista" data-nodo-vista="s1" hidden>
				<span class="jn-ficha__etiqueta">nodo · salto 1</span>
				<h3>Salto 1</h3>
				<p>Recibe el paquete, retira su capa y lo reenvía al salto 2. No necesita saber qué hay dentro.</p>
				<dl class="jn-ficha__datos">
					<div><dt>ve</dt><dd>tu IP; el salto 2; que el paquete va cifrado</dd></div>
					<div><dt>no ve</dt><dd>el destino final; el contenido</dd></div>
				</dl>
			</div>
			<div class="jn-ficha__vista" data-nodo-vista="s2" hidden>
				<span class="jn-ficha__etiqueta">nodo · salto 2</span>
				<h3>El intermedio</h3>
				<p>Es el tramo que más separa el origen del destino: conoce a sus vecinos, no a los extremos.</p>
				<dl class="jn-ficha__datos">
					<div><dt>ve</dt><dd>el salto 1 y el salto 3; el paquete cifrado</dd></div>
					<div><dt>no ve</dt><dd>tu IP; el destino; el contenido</dd></div>
				</dl>
			</div>
			<div class="jn-ficha__vista" data-nodo-vista="s3" hidden>
				<span class="jn-ficha__etiqueta">nodo · salto 3</span>
				<h3>Salto 3</h3>
				<p>Cierra el circuito: recibe del salto 2 y entrega en el destino, sin ver el contenido.</p>
				<dl class="jn-ficha__datos">
					<div><dt>ve</dt><dd>el salto 2; el destino; el paquete cifrado</dd></div>
					<div><dt>no ve</dt><dd>tu IP; el contenido</dd></div>
				</dl>
			</div>
			<div class="jn-ficha__vista" data-nodo-vista="destino" hidden>
				<span class="jn-ficha__etiqueta">nodo · destino</span>
				<h3>El destino</h3>
				<p>Descifra la petición y responde. La respuesta vuelve por el mismo circuito.</p>
				<dl class="jn-ficha__datos">
					<div><dt>ve</dt><dd>la petición descifrada; la IP del salto 3</dd></div>
					<div><dt>no ve</dt><dd>tu IP real; el camino completo</dd></div>
				</dl>
			</div>
		</aside>
	</div>
	<p class="jn-aviso">Mapa educativo. No representa la topología real ni el estado de los nodos.</p>
</section>

<section class="jn-bloque" id="viaje" aria-labelledby="viaje-tit">
	<header class="jn-bloque__cab">
		<span class="jn-kicker"><b>02</b> simulador · tres saltos</span>
		<h2 class="jn-bloque__tit" id="viaje-tit">El viaje de <em>un paquete</em></h2>
		<p class="jn-bloque__intro">Una petición, tres saltos y una respuesta. Inicia el recorrido y observa cómo cambia lo que cada tramo sabe.</p>
	</header>
	<div class="jn-viaje" data-jn-viaje>
		<div class="jn-viaje__mandos">
			<button type="button" class="jn-btn" data-jn-viaje-play>iniciar viaje</button>
			<button type="button" class="jn-btn jn-btn--fantasma" data-jn-viaje-paso>paso a paso</button>
			<button type="button" class="jn-btn jn-btn--fantasma" data-jn-viaje-reset>reiniciar</button>
			<span class="jn-viaje__estado" data-jn-viaje-estado>en espera</span>
		</div>
		<div class="jn-viaje__carril">
			<div class="jn-viaje__riel" aria-hidden="true"></div>
			<div class="jn-viaje__paquete" data-jn-paquete aria-hidden="true"><span>▣</span></div>
			<ol class="jn-viaje__paradas">
				<li data-parada="0"><b>tú</b><span>petición</span></li>
				<li data-parada="1"><b>salto 1</b><span>capa 1</span></li>
				<li data-parada="2"><b>salto 2</b><span>capa 2</span></li>
				<li data-parada="3"><b>salto 3</b><span>capa 3</span></li>
				<li data-parada="4"><b>destino</b><span>respuesta</span></li>
			</ol>
		</div>
		<div class="jn-viaje__barra" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-label="Progreso del viaje"><i data-jn-viaje-barra></i></div>
		<div class="jn-viaje__narracion">
			<div class="jn-viaje__etapa" data-etapa="0">
				<span class="jn-viaje__num">00</span>
				<h3>Todo empieza en tu navegador</h3>
				<p>La aplicación no se conecta al destino: entrega la petición al primer salto mediante SOCKS5. Ahí comienza el circuito.</p>
			</div>
			<div class="jn-viaje__etapa" data-etapa="1" hidden>
				<span class="jn-viaje__num">01</span>
				<h3>Salto 1 · la primera capa</h3>
				<p>El salto 1 sabe de dónde viene el paquete y a quién debe reenviarlo. Abre su capa, no el contenido.</p>
			</div>
			<div class="jn-viaje__etapa" data-etapa="2" hidden>
				<span class="jn-viaje__num">02</span>
				<h3>Salto 2 · el tramo ciego</h3>
				<p>El salto intermedio no conoce ni tu IP ni el destino final. Solo a sus dos vecinos.</p>
			</div>
			<div class="jn-viaje__etapa" data-etapa="3" hidden>
				<span class="jn-viaje__num">03</span>
				<h3>Salto 3 · la entrega</h3>
				<p>El último salto entrega el paquete al destino. Sabe a quién lo entrega, no qué lleva dentro.</p>
			</div>
			<div class="jn-viaje__etapa" data-etapa="4" hidden>
				<span class="jn-viaje__num">04</span>
				<h3>Destino · la respuesta</h3>
				<p>El destino descifra la petición y responde. La respuesta vuelve por el mismo camino y el circuito se cierra.</p>
			</div>
		</div>
		<div class="jn-viaje__pistas">
			<span><b>1</b> inicia el viaje</span>
			<span><b>2</b> sigue el paquete</span>
			<span><b>3</b> reinicia cuando quieras</span>
		</div>
	</div>
	<p class="jn-aviso">Simulación educativa. No abre conexiones reales ni envía tráfico.</p>
</section>

<section class="jn-bloque" id="cifrado" aria-labelledby="cifrado-tit">
	<header class="jn-bloque__cab">
		<span class="jn-kicker"><b>03</b> cifrado por saltos</span>
		<h2 class="jn-bloque__tit" id="cifrado-tit">Qué ve <em>cada salto</em></h2>
		<p class="jn-bloque__intro">El contenido y el camino se protegen por capas. Elige un punto del circuito y comprueba qué se ve desde ahí.</p>
	</header>
	<div class="jn-cif" data-jn-cif data-vista="tu">
		<div class="jn-cif__tabs" role="tablist" aria-label="Punto de vista">
			<button type="button" role="tab" id="jn-cif-tab-tu" aria-controls="jn-cif-panel-tu" aria-selected="true" data-vista-btn="tu">tú</button>
			<button type="button" role="tab" id="jn-cif-tab-s1" aria-controls="jn-cif-panel-s1" aria-selected="false" tabindex="-1" data-vista-btn="s1">salto 1</button>
			<button type="button" role="tab" id="jn-cif-tab-s2" aria-controls="jn-cif-panel-s2" aria-selected="false" tabindex="-1" data-vista-btn="s2">salto 2</button>
			<button type="button" role="tab" id="jn-cif-tab-s3" aria-controls="jn-cif-panel-s3" aria-selected="false" tabindex="-1" data-vista-btn="s3">salto 3</button>
			<button type="button" role="tab" id="jn-cif-tab-destino" aria-controls="jn-cif-panel-destino" aria-selected="false" tabindex="-1" data-vista-btn="destino">destino</button>
		</div>
		<div class="jn-cif__panel">
			<div class="jn-cif__sobre" aria-hidden="true">
				<div class="jn-cif__capa jn-cif__capa--1"><span>destino</span></div>
				<div class="jn-cif__capa jn-cif__capa--2"><span>siguiente salto</span></div>
				<div class="jn-cif__capa jn-cif__capa--3"><span>contenido</span><b>JENC</b></div>
			</div>
			<div class="jn-cif__fichas">
				<div class="jn-cif__ficha" id="jn-cif-panel-tu" role="tabpanel" aria-labelledby="jn-cif-tab-tu" tabindex="0" data-vista="tu">
					<span class="jn-ficha__etiqueta">punto de vista · origen</span>
					<h3>Tú</h3>
					<p>Conoces el destino y el contenido. Lo que no ves es el camino que tomará por dentro.</p>
					<dl class="jn-ficha__datos">
						<div><dt>visible</dt><dd>destino final; contenido sin cifrar</dd></div>
						<div><dt>oculto</dt><dd>la ruta interna entre saltos</dd></div>
					</dl>
				</div>
				<div class="jn-cif__ficha" id="jn-cif-panel-s1" role="tabpanel" aria-labelledby="jn-cif-tab-s1" tabindex="0" data-vista="s1" hidden>
					<span class="jn-ficha__etiqueta">punto de vista · salto 1</span>
					<h3>Salto 1</h3>
					<p>Tu dirección y el siguiente salto. El contenido sigue cerrado y el destino final no aparece.</p>
					<dl class="jn-ficha__datos">
						<div><dt>visible</dt><dd>tu IP; salto 2; el sobre cifrado</dd></div>
						<div><dt>oculto</dt><dd>destino final; contenido</dd></div>
					</dl>
				</div>
				<div class="jn-cif__ficha" id="jn-cif-panel-s2" role="tabpanel" aria-labelledby="jn-cif-tab-s2" tabindex="0" data-vista="s2" hidden>
					<span class="jn-ficha__etiqueta">punto de vista · salto 2</span>
					<h3>Salto 2</h3>
					<p>El tramo intermedio. Solo conoce a sus vecinos; no sabe quién empezó ni quién recibe.</p>
					<dl class="jn-ficha__datos">
						<div><dt>visible</dt><dd>salto 1; salto 3; el sobre cifrado</dd></div>
						<div><dt>oculto</dt><dd>tu IP; destino final; contenido</dd></div>
					</dl>
				</div>
				<div class="jn-cif__ficha" id="jn-cif-panel-s3" role="tabpanel" aria-labelledby="jn-cif-tab-s3" tabindex="0" data-vista="s3" hidden>
					<span class="jn-ficha__etiqueta">punto de vista · salto 3</span>
					<h3>Salto 3</h3>
					<p>El último tramo. Sabe a quién entregar y de dónde viene el paquete; el contenido no se abre aquí.</p>
					<dl class="jn-ficha__datos">
						<div><dt>visible</dt><dd>salto 2; destino; el sobre cifrado</dd></div>
						<div><dt>oculto</dt><dd>tu IP; contenido</dd></div>
					</dl>
				</div>
				<div class="jn-cif__ficha" id="jn-cif-panel-destino" role="tabpanel" aria-labelledby="jn-cif-tab-destino" tabindex="0" data-vista="destino" hidden>
					<span class="jn-ficha__etiqueta">punto de vista · destino</span>
					<h3>Destino</h3>
					<p>Recibe la petición descifrada. Ve la IP del último salto, no la tuya ni el camino completo.</p>
					<dl class="jn-ficha__datos">
						<div><dt>visible</dt><dd>contenido; IP del salto 3</dd></div>
						<div><dt>oculto</dt><dd>tu IP real; la ruta completa</dd></div>
					</dl>
				</div>
			</div>
		</div>
		<p class="jn-aviso">Modelo educativo simplificado de JENC, el cifrado por capas de JumperNET.</p>
	</div>
</section>

<section class="jn-bloque" id="comparar" aria-labelledby="comparar-tit">
	<header class="jn-bloque__cab">
		<span class="jn-kicker"><b>04</b> comparador</span>
		<h2 class="jn-bloque__tit" id="comparar-tit">Directa o <em>en tres saltos</em></h2>
		<p class="jn-bloque__intro">Una conexión directa es más corta; una de tres saltos reparte lo que cada intermediario sabe. No hay una mejor para todo.</p>
	</header>
	<div class="jn-comp" data-jn-comp data-activo="saltos">
		<div class="jn-comp__conmutador" role="group" aria-label="Resaltar una conexión">
			<button type="button" data-jn-comp-btn="directa" aria-pressed="false">directa</button>
			<button type="button" data-jn-comp-btn="saltos" aria-pressed="true">tres saltos</button>
		</div>
		<div class="jn-comp__lados">
			<article class="jn-comp__lado" data-comp="directa">
				<span class="jn-kicker">sin intermediarios</span>
				<h3>Conexión directa</h3>
				<ul>
					<li>El destino ve tu IP real.</li>
					<li>Tu operador ve a qué destino te conectas.</li>
					<li>Un solo tramo: menos latencia.</li>
					<li>No reparte la confianza entre nodos.</li>
				</ul>
			</article>
			<article class="jn-comp__lado" data-comp="saltos">
				<span class="jn-kicker">tres saltos</span>
				<h3>Circuito JumperNET</h3>
				<ul>
					<li>El destino ve la IP de un salto, no la tuya.</li>
					<li>Ningún salto ve a la vez origen, destino y contenido.</li>
					<li>Tres tramos: más latencia que una conexión directa.</li>
					<li>La confianza se reparte entre varios operadores.</li>
				</ul>
			</article>
		</div>
		<div class="jn-tabla-envoltura">
			<table class="jn-tabla">
				<caption class="jn-visually-hidden">Comparación cualitativa entre conexión directa y de tres saltos</caption>
				<thead><tr><th scope="col">criterio</th><th scope="col">directa</th><th scope="col">tres saltos</th></tr></thead>
				<tbody>
					<tr><th scope="row">tu IP</th><td>la ve el destino</td><td>la ve el salto 1</td></tr>
					<tr><th scope="row">destino</th><td>lo ve tu operador</td><td>lo ve el salto 3</td></tr>
					<tr><th scope="row">contenido</th><td>según el cifrado de la web</td><td>cifrado por capas entre saltos</td></tr>
					<tr><th scope="row">latencia</th><td>menor</td><td>mayor</td></tr>
					<tr><th scope="row">confianza</th><td>en un solo camino</td><td>repartida entre nodos</td></tr>
				</tbody>
			</table>
		</div>
		<p class="jn-aviso">Comparación cualitativa. No son medidas de rendimiento de esta instalación.</p>
	</div>
</section>

<section class="jn-bloque" id="estado" aria-labelledby="estado-tit">
	<header class="jn-bloque__cab">
		<span class="jn-kicker"><b>05</b> estado</span>
		<h2 class="jn-bloque__tit" id="estado-tit">La instalación, <em>en datos</em></h2>
		<p class="jn-bloque__intro">Datos reales de esta instalación de WordPress, no métricas de la red.</p>
	</header>
	<div class="jn-estado" data-jn-estado>
		<div class="jn-estado__rejilla">
			<div class="jn-estado__dato"><span>entradas publicadas</span><b>{{POSTS}}</b></div>
			<div class="jn-estado__dato"><span>páginas</span><b>{{PAGES}}</b></div>
			<div class="jn-estado__dato"><span>archivos</span><b>{{MEDIA}}</b></div>
			<div class="jn-estado__dato"><span>comentarios</span><b>{{COMMENTS}}</b></div>
			<div class="jn-estado__dato"><span>tema activo</span><b>v{{TEMA}}</b></div>
			<div class="jn-estado__dato"><span>vídeo</span><b>{{VIDEO}}</b></div>
			<div class="jn-estado__dato"><span>modo</span><b data-jn-modo>claro</b></div>
			<div class="jn-estado__dato"><span>generado</span><b class="jn-estado__fecha">{{FECHA}}</b></div>
		</div>
		<p class="jn-aviso">Instantánea del sitio, generada al cargar la página. No hay monitorización de nodos remotos.</p>
	</div>
</section>

<section class="jn-bloque" id="terminal" aria-labelledby="terminal-tit">
	<header class="jn-bloque__cab">
		<span class="jn-kicker"><b>06</b> terminal</span>
		<h2 class="jn-bloque__tit" id="terminal-tit">Comandos, <em>sin sustos</em></h2>
		<p class="jn-bloque__intro">Comandos que se usan con un proxy SOCKS5, explicados sin ejecutar nada. Todo ocurre en tu navegador.</p>
	</header>
	<div class="jn-term" data-jn-term>
		<div class="jn-term__barra" aria-hidden="true"><i></i><i></i><i></i><span>consola educativa · simulada</span></div>
		<div class="jn-term__salida" data-jn-term-salida aria-live="polite">
			<p class="jn-term__bienvenida">JumperNET · consola educativa
Escribe «help» para ver los comandos disponibles.
Nada de lo que escribas sale de tu navegador.</p>
		</div>
		<form class="jn-term__linea" data-jn-term-form>
			<label class="jn-visually-hidden" for="jn-term-input">Comando</label>
			<span aria-hidden="true">$</span>
			<input id="jn-term-input" data-jn-term-input type="text" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="help">
			<button type="submit">ejecutar</button>
		</form>
		<div class="jn-term__sugerencias" data-jn-term-sugerencias>
			<span>prueba:</span>
			<button type="button" data-jn-term-chip="help">help</button>
			<button type="button" data-jn-term-chip="curl --socks5-hostname">curl</button>
			<button type="button" data-jn-term-chip="ssh -D 1080">ssh -D</button>
			<button type="button" data-jn-term-chip="jumpernet estado">estado</button>
			<button type="button" data-jn-term-chip="clear">clear</button>
		</div>
	</div>
	<p class="jn-aviso">Los resultados son ejemplos ilustrativos, no la salida de una ejecución real.</p>
</section>

<section class="jn-bloque" id="glosario" aria-labelledby="glosario-tit">
	<header class="jn-bloque__cab">
		<span class="jn-kicker"><b>07</b> glosario</span>
		<h2 class="jn-bloque__tit" id="glosario-tit">Diez palabras <em>para seguir</em></h2>
		<p class="jn-bloque__intro">Lo justo para leer la documentación sin frenarte. Filtra o abre el término que te interese.</p>
	</header>
	<div class="jn-glos" data-jn-glos>
		<div class="jn-glos__filtro">
			<label class="jn-visually-hidden" for="jn-glos-buscar">Buscar un término</label>
			<input id="jn-glos-buscar" data-jn-glos-buscar type="search" placeholder="filtrar: cifrado, salto, DNS…">
			<span data-jn-glos-cuenta>10 términos</span>
		</div>
		<div class="jn-glos__lista">
			<details class="jn-glos__item"><summary><b>salto</b><span>relay</span></summary><p>Nodo que recibe un paquete y lo reenvía al siguiente punto del circuito. En JumperNET hay tres por defecto.</p></details>
			<details class="jn-glos__item"><summary><b>SOCKS5</b><span>protocolo</span></summary><p>Permite que una aplicación entregue su conexión a un proxy sin que ella misma hable con el destino.</p></details>
			<details class="jn-glos__item"><summary><b>JENC</b><span>cifrado del proyecto</span></summary><p>Cifrado por capas: cada salto abre únicamente la capa que le corresponde y desconoce el resto.</p></details>
			<details class="jn-glos__item"><summary><b>paquete</b><span>unidad de datos</span></summary><p>Bloque pequeño de información que viaja por la red. Los paquetes no llevan el vídeo entero: se reparten.</p></details>
			<details class="jn-glos__item"><summary><b>nodo</b><span>punto del circuito</span></summary><p>Cualquier equipo que participa: tu origen, un salto o el destino. Cada nodo tiene un papel distinto.</p></details>
			<details class="jn-glos__item"><summary><b>metadatos</b><span>lo que rodea al contenido</span></summary><p>Origen, destino, hora o tamaño. Aunque el contenido vaya cifrado, parte de los metadatos sigue siendo visible.</p></details>
			<details class="jn-glos__item"><summary><b>DNS</b><span>nombres → direcciones</span></summary><p>Traduce un nombre como <code>ejemplo.test</code> a una dirección IP. Resolverlo por el proxy evita fugas.</p></details>
			<details class="jn-glos__item"><summary><b>túnel</b><span>conexión encapsulada</span></summary><p>Una conexión dentro de otra. El túnel transporta el tráfico sin que el camino intermedio lo interprete.</p></details>
			<details class="jn-glos__item"><summary><b>latencia</b><span>tiempo de ida y vuelta</span></summary><p>Lo que tarda una respuesta en volver. Más saltos suele significar más latencia, aunque depende de la ruta.</p></details>
			<details class="jn-glos__item"><summary><b>extremo a extremo</b><span>cifrado</span></summary><p>Solo el origen y el destino pueden abrir el contenido. Los intermediarios lo transportan sin leerlo.</p></details>
		</div>
	</div>
</section>

<section class="jn-bloque" id="preguntas" aria-labelledby="preguntas-tit">
	<header class="jn-bloque__cab">
		<span class="jn-kicker"><b>08</b> preguntas</span>
		<h2 class="jn-bloque__tit" id="preguntas-tit">Lo que <em>suele preguntarse</em></h2>
		<p class="jn-bloque__intro">Respuestas cortas. Si necesitas el detalle, la documentación está a un clic.</p>
	</header>
	<div class="jn-faq">
		<details class="jn-faq__item"><summary>¿JumperNET guarda mi tráfico?</summary><p>Esta web es la documentación del proyecto: no opera la red ni recibe tu tráfico. Lo que hace el circuito real se describe en la documentación técnica.</p></details>
		<details class="jn-faq__item"><summary>¿Cuántos saltos usa el circuito?</summary><p>Tres por defecto. El origen conoce el primero, el primero al segundo y así hasta el destino; cada tramo sabe lo mínimo.</p></details>
		<details class="jn-faq__item"><summary>¿Puedo usar el navegador sin la extensión?</summary><p>Sí. La extensión facilita el día a día, pero un cliente SOCKS5 configurado a mano también puede usar el circuito.</p></details>
		<details class="jn-faq__item"><summary>¿Qué pasa si un salto falla?</summary><p>El circuito se reconstruye con otro nodo disponible. La guía de problemas y soluciones explica cómo detectarlo.</p></details>
		<details class="jn-faq__item"><summary>¿El cifrado oculta que me conecto?</summary><p>Oculta el contenido y reparte el camino, pero no vuelve invisible el hecho de que hay tráfico. Ningún sistema serio promete eso.</p></details>
		<details class="jn-faq__item"><summary>¿Por dónde empiezo?</summary><p>Por la guía de primeros pasos y, si quieres el contexto, por «Qué es JumperNET y por qué existe».</p></details>
	</div>
</section>

<section class="jn-bloque" id="bajo-el-capo" aria-labelledby="capo-tit">
	<header class="jn-bloque__cab">
		<span class="jn-kicker"><b>09</b> bajo el capó</span>
		<h2 class="jn-bloque__tit" id="capo-tit">Cómo está <em>hecha esta web</em></h2>
		<p class="jn-bloque__intro">Sin dependencias externas ni efectos de escaparate: piezas estándar, movimiento medido y datos que se pueden comprobar.</p>
	</header>
	<div class="jn-cap">
		<div class="jn-cap__col">
			<div class="jn-cap__chips">
				<span>WordPress</span><span>Twenty Twenty-Four</span><span>SOCKS5</span><span>JENC</span><span>SVG + Canvas</span><span>prefers-reduced-motion</span>
			</div>
			<p class="jn-cap__nota">El tema es hijo: el contenido sigue siendo editable desde WordPress y las experiencias se añaden solo en la portada. El vídeo se sirve desde <code>assets/</code> sin servicios externos.</p>
			<p class="jn-cap__enlaces"><a class="jn-btn" href="{{GUIA}}">empezar por la guía</a> <a class="jn-btn jn-btn--fantasma" href="{{DOCS}}">ver toda la documentación</a></p>
		</div>
		<div class="jn-cap__col">
			<h3 class="jn-cap__tit">bitácora</h3>
			<ol class="jn-bitacora">
				<li><b>v2.1.0</b><span>fondo de red visible, cabecera compacta, navegación entre experiencias y reproductor con portada.</span></li>
				<li><b>v2.0.0</b><span>modo claro/oscuro, fondo de red, portada editorial y experiencias educativas.</span></li>
				<li><b>v1.3.0</b><span>vídeo junto al título y película completa en la portada.</span></li>
				<li><b>v1.2.0</b><span>intro cinematográfica, cabecera nueva y panel de inicio.</span></li>
			</ol>
		</div>
	</div>
</section>

<section class="jn-bloque jn-bloque--navidad" id="navidad" aria-labelledby="navidad-tit">
	<div class="jn-nav">
		<div class="jn-nav__arbol" aria-hidden="true">
			<svg viewBox="0 0 320 310">
				<g class="jn-nav__ramas">
					<path d="M55 250 L80 205 M105 250 L80 205 M105 250 L130 205 M155 250 L130 205 M155 250 L180 205 M205 250 L180 205 M205 250 L230 205 M255 250 L230 205"/>
					<path d="M80 205 L105 160 M130 205 L105 160 M130 205 L155 160 M180 205 L155 160 M180 205 L205 160 M230 205 L205 160"/>
					<path d="M105 160 L130 115 M155 160 L130 115 M155 160 L180 115 M205 160 L180 115"/>
					<path d="M130 115 L155 78 M180 115 L155 78"/>
					<path class="jn-nav__tronco" d="M155 250 L155 292"/>
				</g>
				<g class="jn-nav__nodos">
					<circle cx="55" cy="250" r="6"/><circle cx="105" cy="250" r="6"/><circle cx="155" cy="250" r="6"/><circle cx="205" cy="250" r="6"/><circle cx="255" cy="250" r="6"/>
					<circle cx="80" cy="205" r="6"/><circle cx="130" cy="205" r="6"/><circle cx="180" cy="205" r="6"/><circle cx="230" cy="205" r="6"/>
					<circle cx="105" cy="160" r="6"/><circle cx="155" cy="160" r="6"/><circle cx="205" cy="160" r="6"/>
					<circle cx="130" cy="115" r="6"/><circle cx="180" cy="115" r="6"/>
					<circle class="jn-nav__corona" cx="155" cy="78" r="7"/>
				</g>
				<path class="jn-nav__estrella" d="M160 20 l6 15 16 2 -12 11 3 16 -13 -9 -13 9 3 -16 -12 -11 16 -2z"/>
			</svg>
		</div>
		<div class="jn-nav__texto">
			<span class="jn-kicker">temporada · 2026</span>
			<h2 class="jn-bloque__tit" id="navidad-tit">Un árbol hecho <em>de nodos</em></h2>
			<p>Cada luz es una conexión y cada rama un tramo. La red no se apaga en fiestas: solo cambia de ambiente.</p>
			<p class="jn-nav__saludo">{{SALUDO}}</p>
			<span class="jn-nav__firma">desde la documentación de JumperNET</span>
		</div>
	</div>
</section>

</div>
HTML;

	return str_replace(array_keys($datos), array_values($datos), $html);
}

/* ─── controles flotantes: tema y recorrido guiado ─── */
add_action('wp_footer', function () {
	$front = is_front_page();
	?>
	<div class="jn-fabs" role="group" aria-label="Controles del sitio">
		<button type="button" class="jn-fab" data-jn-tema-btn aria-pressed="false" aria-label="Cambiar a modo oscuro">
			<span class="jn-fab__icono" aria-hidden="true">◐</span>
			<span class="jn-fab__txt">oscuro</span>
		</button>
		<?php if ($front) : ?>
			<button type="button" class="jn-fab jn-fab--tour" data-jn-tour-ini aria-label="Iniciar el recorrido guiado">
				<span aria-hidden="true">→</span>
				<span class="jn-fab__txt">recorrido</span>
			</button>
		<?php endif; ?>
	</div>
	<?php if ($front) : ?>
		<div class="jn-tour" data-jn-tour hidden aria-live="polite">
			<span class="jn-tour__paso" data-jn-tour-paso>1 / 6</span>
			<p class="jn-tour__txt" data-jn-tour-txt>La portada completa, en un minuto.</p>
			<div class="jn-tour__mandos">
				<button type="button" class="jn-btn jn-btn--mini" data-jn-tour-next>siguiente</button>
				<button type="button" class="jn-btn jn-btn--fantasma jn-btn--mini" data-jn-tour-fin>salir</button>
			</div>
		</div>
	<?php endif; ?>
	<?php
}, 6);

/* ═══════════════════════════════════════════════════════════════════
   PANEL AL INICIAR SESIÓN
   ═══════════════════════════════════════════════════════════════════ */

function jn_contar_adjuntos() {
	$total = 0;
	foreach ((array) wp_count_attachments() as $estado) {
		if (isset($estado->count)) {
			$total += (int) $estado->count;
		}
	}
	return $total;
}

function jn_contar_comentarios() {
	$c = wp_count_comments();
	return (int) $c->approved + (int) $c->moderated + (int) $c->spam;
}

function jn_acciones_rapidas() {
	$acciones = array();
	if (current_user_can('edit_posts')) {
		$acciones[] = array('✎', 'Nueva entrada', admin_url('post-new.php'), 'Escribe un artículo de la documentación');
	}
	if (current_user_can('edit_pages')) {
		$acciones[] = array('▤', 'Nueva página', admin_url('post-new.php?post_type=page'), 'Añade una página nueva al sitio');
	}
	if (current_user_can('upload_files')) {
		$acciones[] = array('⇪', 'Subir archivo', admin_url('media-new.php'), 'Imágenes, capturas y vídeos');
	}
	if (current_user_can('moderate_comments')) {
		$acciones[] = array('✉', 'Comentarios', admin_url('edit-comments.php'), 'Revisa lo que llega');
	}
	if (current_user_can('edit_theme_options')) {
		$acciones[] = array('◈', 'Personalizar', admin_url('customize.php'), 'Colores, cabecera y menús');
		$acciones[] = array('≡', 'Menús', admin_url('nav-menus.php'), 'Estructura de navegación');
	}
	if (current_user_can('manage_options')) {
		$acciones[] = array('⚙', 'Ajustes', admin_url('options-general.php'), 'Opciones generales del sitio');
	}
	$acciones[] = array('▶', 'Ver «El viaje»', home_url('/#el-viaje'), 'El vídeo de la portada');
	$acciones[] = array('⌂', 'Ver la web', home_url('/'), 'Abre el sitio publicado');
	return $acciones;
}

/* widget del escritorio */
add_action('wp_dashboard_setup', function () {
	if (!current_user_can('edit_posts')) return;
	wp_add_dashboard_widget('jn_panel', 'JumperNET · panel rápido', 'jn_panel_widget');
});

function jn_panel_widget() {
	$post     = wp_count_posts('post');
	$page     = wp_count_posts('page');
	$usuarios = count_users();
	$fichas   = array(
		array(isset($post->publish) ? (int) $post->publish : 0, 'entradas'),
		array(isset($page->publish) ? (int) $page->publish : 0, 'páginas'),
		array(jn_contar_adjuntos(), 'archivos'),
		array(jn_contar_comentarios(), 'comentarios'),
		array(current_user_can('list_users') ? (int) $usuarios['total_users'] : '—', 'usuarios'),
	);
	?>
	<div class="jn-panel">
		<div class="jn-panel__cab">
			<span class="jn-panel__logo" aria-hidden="true">↯</span>
			<div class="jn-panel__marca">
				<b>JumperNET</b>
				<span>documentación · v<?php echo esc_html(JN_VERSION); ?></span>
			</div>
			<span class="jn-panel__estado"><i></i>en línea</span>
		</div>

		<div class="jn-panel__stats">
			<?php foreach ($fichas as $ficha) : ?>
				<div class="jn-panel__stat">
					<b><?php echo esc_html((string) $ficha[0]); ?></b>
					<span><?php echo esc_html($ficha[1]); ?></span>
				</div>
			<?php endforeach; ?>
		</div>

		<h3 class="jn-panel__tit">Qué quieres hacer</h3>
		<div class="jn-panel__acciones">
			<?php foreach (jn_acciones_rapidas() as $accion) : ?>
				<a class="jn-panel__accion" href="<?php echo esc_url($accion[2]); ?>">
					<span class="jn-panel__icono" aria-hidden="true"><?php echo esc_html($accion[0]); ?></span>
					<b><?php echo esc_html($accion[1]); ?></b>
					<small><?php echo esc_html($accion[3]); ?></small>
				</a>
			<?php endforeach; ?>
		</div>

		<?php
		$recientes = get_posts(array(
			'numberposts' => 5,
			'post_type'   => 'post',
			'post_status' => array('publish', 'draft', 'pending', 'private'),
		));
		if ($recientes) :
			?>
			<h3 class="jn-panel__tit">Últimos documentos</h3>
			<ul class="jn-panel__lista">
				<?php foreach ($recientes as $doc) :
					$estado = ($doc->post_status === 'publish') ? 'publicado' : $doc->post_status;
					?>
					<li>
						<a href="<?php echo esc_url(get_edit_post_link($doc->ID)); ?>"><?php echo esc_html(get_the_title($doc) ?: '(sin título)'); ?></a>
						<span class="jn-panel__meta"><?php echo esc_html($estado); ?> · <?php echo esc_html(get_the_date('j M', $doc)); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<p class="jn-panel__pie">
			<a href="<?php echo esc_url(admin_url('admin.php?page=jumpernet')); ?>">Abrir el panel completo →</a>
		</p>
	</div>
	<?php
}

/* menú propio */
add_action('admin_menu', function () {
	add_menu_page('JumperNET', 'JumperNET', 'edit_posts', 'jumpernet', 'jn_pagina_admin', 'dashicons-superhero', 3);
});

function jn_pagina_admin() {
	if (!current_user_can('edit_posts')) return;

	$post     = wp_count_posts('post');
	$page     = wp_count_posts('page');
	$usuarios = count_users();
	$documentos = get_posts(array(
		'numberposts' => 30,
		'post_type'   => 'post',
		'post_status' => array('publish', 'draft', 'pending', 'private'),
	));
	?>
	<div class="wrap jn-adm">
		<div class="jn-adm-cab">
			<span class="jn-adm-marca" aria-hidden="true">↯</span>
			<div>
				<h1>JumperNET · panel</h1>
				<p>Hola<?php echo esc_html(wp_get_current_user()->display_name ? ', ' . wp_get_current_user()->display_name : ''); ?>. Todo lo que puedes hacer desde aquí.</p>
			</div>
			<div class="jn-adm-cab__acciones">
				<a class="jn-btn jn-btn--prin" href="<?php echo esc_url(home_url('/')); ?>" target="_blank" rel="noopener">ver la web ↗</a>
				<a class="jn-btn jn-btn--fant" href="<?php echo esc_url(home_url('/#el-viaje')); ?>" target="_blank" rel="noopener">▶ el viaje</a>
			</div>
		</div>

		<div class="jn-adm-stats">
			<div class="jn-adm-stat"><b><?php echo esc_html((string) (isset($post->publish) ? $post->publish : 0)); ?></b><span>entradas publicadas</span></div>
			<div class="jn-adm-stat"><b><?php echo esc_html((string) (isset($page->publish) ? $page->publish : 0)); ?></b><span>páginas</span></div>
			<div class="jn-adm-stat"><b><?php echo esc_html((string) jn_contar_adjuntos()); ?></b><span>archivos</span></div>
			<div class="jn-adm-stat"><b><?php echo esc_html((string) jn_contar_comentarios()); ?></b><span>comentarios</span></div>
			<div class="jn-adm-stat"><b><?php echo esc_html(current_user_can('list_users') ? (string) $usuarios['total_users'] : '—'); ?></b><span>usuarios</span></div>
			<div class="jn-adm-stat jn-adm-stat--ver"><b>v<?php echo esc_html(JN_VERSION); ?></b><span>tema activo</span></div>
		</div>

		<h2 class="jn-adm-tit">Accesos rápidos</h2>
		<div class="jn-adm-grid">
			<?php foreach (jn_acciones_rapidas() as $accion) : ?>
				<a class="jn-adm-card" href="<?php echo esc_url($accion[2]); ?>">
					<span class="jn-adm-card__icono" aria-hidden="true"><?php echo esc_html($accion[0]); ?></span>
					<b><?php echo esc_html($accion[1]); ?></b>
					<small><?php echo esc_html($accion[3]); ?></small>
				</a>
			<?php endforeach; ?>
		</div>

		<div class="jn-adm-cols">
			<div class="jn-adm-caja">
				<h2 class="jn-adm-tit">Documentos</h2>
				<?php if ($documentos) : ?>
					<table class="jn-adm-tabla">
						<thead>
							<tr><th>Título</th><th>Estado</th><th>Fecha</th><th></th></tr>
						</thead>
						<tbody>
							<?php foreach ($documentos as $doc) : ?>
								<tr>
									<td><a href="<?php echo esc_url(get_edit_post_link($doc->ID)); ?>"><?php echo esc_html(get_the_title($doc) ?: '(sin título)'); ?></a></td>
									<td><span class="jn-adm-chip"><?php echo esc_html($doc->post_status === 'publish' ? 'publicado' : $doc->post_status); ?></span></td>
									<td><?php echo esc_html(get_the_date('j M Y', $doc)); ?></td>
									<td class="jn-adm-tabla__acc">
										<a href="<?php echo esc_url(get_edit_post_link($doc->ID)); ?>">editar</a>
										<a href="<?php echo esc_url(get_permalink($doc)); ?>" target="_blank" rel="noopener">ver ↗</a>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else : ?>
					<p class="jn-adm-vacio">Todavía no hay documentos. <a href="<?php echo esc_url(admin_url('post-new.php')); ?>">Escribe el primero</a>.</p>
				<?php endif; ?>
			</div>

			<div class="jn-adm-caja">
				<h2 class="jn-adm-tit">El viaje</h2>
				<?php if (jn_hay_video()) : ?>
					<video class="jn-adm-video" src="<?php echo esc_url(jn_asset_uri('el-viaje.mp4')); ?>" controls preload="metadata" playsinline></video>
					<p class="jn-adm-nota">7:16 · 1280×720. Arriba a la derecha del título se reproduce en bucle un corte de 30 s; completo en la sección «El viaje»; y una vez por sesión a pantalla completa al entrar. Hay un único archivo de vídeo: el corte de 30 s es el primer tramo del mismo documental.</p>
					<p class="jn-adm-nota"><a href="<?php echo esc_url(home_url('/#el-viaje')); ?>" target="_blank" rel="noopener">Abrir en la portada ↗</a></p>
				<?php else : ?>
					<p class="jn-adm-vacio">No se encuentra <code>assets/el-viaje.mp4</code>.</p>
				<?php endif; ?>

				<h2 class="jn-adm-tit">Notas de la versión</h2>
				<ul class="jn-adm-lista">
					<li><b>v2.1.0</b> · fondo de red visible en ambos modos, cabecera compacta, índice de experiencias con sección activa, reproductor con portada y controles educativos en mapa, simulador y terminal.</li>
					<li><b>v2.0.0</b> · sistema claro/oscuro, fondo de red, portada editorial y experiencias interactivas (mapa, viaje del paquete, cifrado, comparador, terminal, glosario y FAQ).</li>
					<li><b>v1.3.0</b> · vídeo arriba a la derecha del título y película completa de 7 min en la portada, portada más ancha y renovada.</li>
					<li><b>v1.2.0</b> · vídeo «El viaje», portada cinematográfica, fondo animado, cabecera y logo nuevos, panel de inicio.</li>
					<li><b>v1.1.0</b> · paleta coral/violeta, lectura más cómoda y copia rápida de código.</li>
				</ul>
			</div>
		</div>
	</div>
	<?php
}

/* barra de administración */
add_action('admin_bar_menu', function ($bar) {
	if (!is_admin_bar_showing() && !is_admin()) return;

	$bar->add_node(array(
		'id'    => 'jn-crear',
		'title' => '＋ crear',
		'href'  => current_user_can('edit_posts') ? admin_url('post-new.php') : admin_url(),
		'meta'  => array('title' => 'Crear contenido'),
	));
	$hijos = array(
		'jn-crear-entrada' => array('edit_posts', 'Entrada', 'post-new.php'),
		'jn-crear-pagina'  => array('edit_pages', 'Página', 'post-new.php?post_type=page'),
		'jn-crear-medio'   => array('upload_files', 'Archivo', 'media-new.php'),
		'jn-crear-usuario' => array('create_users', 'Usuario', 'user-new.php'),
	);
	foreach ($hijos as $id => $hijo) {
		if (!current_user_can($hijo[0])) continue;
		$bar->add_node(array(
			'id'     => $id,
			'parent' => 'jn-crear',
			'title'  => $hijo[1],
			'href'   => admin_url($hijo[2]),
		));
	}
	if (current_user_can('edit_posts')) {
		$bar->add_node(array(
			'id'    => 'jn-panel',
			'title' => '↯ JumperNET',
			'href'  => admin_url('admin.php?page=jumpernet'),
		));
	}
	$bar->add_node(array(
		'id'    => 'jn-viaje',
		'title' => '▶ el viaje',
		'href'  => home_url('/#el-viaje'),
	));
}, 40);

/* pie del panel */
add_filter('admin_footer_text', function () {
	return 'JumperNET · documentación interna · <span style="color:#ff8a5f">v' . esc_html(JN_VERSION) . '</span>';
});
add_filter('update_footer', function () {
	return 'hecho con ♥ para la red';
}, 11);

/* estilos del panel */
add_action('admin_head', function () {
	?>
	<style>
		#wpadminbar{background:#0d0a14!important}
		#wpadminbar .ab-item,#wpadminbar a.ab-item,#wpadminbar #wp-toolbar span.ab-label{color:#ece4f0!important}
		#wpadminbar .ab-top-menu>li:hover>.ab-item,#wpadminbar .ab-top-menu>li.hover>.ab-item{background:#1b1526!important;color:#fff!important}
		#wpadminbar #wp-admin-bar-jn-crear>.ab-item{background:linear-gradient(135deg,#ff8a63,#ff5a36)!important;color:#241007!important;font-weight:700}
		#wpadminbar #wp-admin-bar-jn-viaje>.ab-item{color:#ffb09a!important}

		.jn-panel{font-size:13px}
		.jn-panel__cab{display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:14px;background:radial-gradient(420px 160px at 92% -40%,rgba(255,90,54,.28),transparent 66%),linear-gradient(180deg,#191323,#0f0c15);border:1px solid #2b2436;margin:0 0 14px}
		.jn-panel__logo{display:grid;place-items:center;width:36px;height:36px;border-radius:11px;font-size:18px;font-weight:800;color:#1b0a04;background:linear-gradient(145deg,#ffb59a,#ff5a36 55%,#b06aff)}
		.jn-panel__marca b{display:block;color:#fff;font-size:15px;letter-spacing:.02em}
		.jn-panel__marca span{color:#a99fae;font-size:11px;font-family:ui-monospace,Consolas,monospace}
		.jn-panel__estado{margin-left:auto;display:inline-flex;align-items:center;gap:6px;font-family:ui-monospace,Consolas,monospace;font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:#9ff5df;border:1px solid rgba(51,214,192,.4);background:rgba(51,214,192,.1);border-radius:999px;padding:3px 10px}
		.jn-panel__estado i{width:6px;height:6px;border-radius:50%;background:#33d6c0;box-shadow:0 0 0 3px rgba(51,214,192,.18)}
		.jn-panel__stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(78px,1fr));gap:8px;margin-bottom:16px}
		.jn-panel__stat{border:1px solid #2b2436;border-radius:11px;padding:9px 11px;background:rgba(255,255,255,.02);text-align:center}
		.jn-panel__stat b{display:block;font-size:19px;color:#ffb09a;font-family:ui-monospace,Consolas,monospace;line-height:1.2}
		.jn-panel__stat span{font-size:10.5px;color:#a99fae}
		.jn-panel__tit{margin:16px 0 9px!important;font-size:11px!important;letter-spacing:.16em;text-transform:uppercase;color:#a99fae!important;font-family:ui-monospace,Consolas,monospace}
		.jn-panel__acciones{display:grid;grid-template-columns:repeat(auto-fit,minmax(148px,1fr));gap:8px}
		.jn-panel__accion{display:grid;gap:1px;padding:10px 12px;border:1px solid #2b2436;border-radius:11px;background:#0e0b13;text-decoration:none;transition:border-color .2s ease,transform .2s ease,background .2s ease}
		.jn-panel__accion:hover{transform:translateY(-2px);border-color:rgba(255,90,54,.55);background:#14101b}
		.jn-panel__icono{color:#ff8a63;font-size:13px;line-height:1}
		.jn-panel__accion b{color:#f7f1e8;font-size:12.5px;font-weight:600}
		.jn-panel__accion small{color:#8f8598;font-size:10.5px;line-height:1.35}
		.jn-panel__lista{margin:0;padding:0;list-style:none}
		.jn-panel__lista li{display:flex;justify-content:space-between;gap:10px;padding:7px 2px;border-bottom:1px solid #221b2c;font-size:12.5px}
		.jn-panel__lista li:last-child{border-bottom:0}
		.jn-panel__lista a{color:#ffb09a;text-decoration:none}
		.jn-panel__lista a:hover{color:#ffd0c0}
		.jn-panel__meta{color:#8f8598;font-family:ui-monospace,Consolas,monospace;font-size:10px;white-space:nowrap}
		.jn-panel__pie{margin:14px 0 0!important}
		.jn-panel__pie a{font-family:ui-monospace,Consolas,monospace;font-size:11.5px;color:#ff8a63;text-decoration:none}
		#jn_panel .inside{background:#0b0910;color:#d9d0dd}

		.jn-adm{max-width:1180px;color:#d9d0dd}
		.jn-adm-cab{display:flex;align-items:center;gap:16px;flex-wrap:wrap;margin:18px 0 20px;padding:20px 22px;border-radius:18px;background:radial-gradient(620px 220px at 92% -40%,rgba(255,90,54,.26),transparent 66%),radial-gradient(420px 200px at 4% 120%,rgba(139,123,255,.22),transparent 60%),linear-gradient(180deg,#191323,#0f0c15);border:1px solid #2b2436;box-shadow:0 26px 60px -46px #000}
		.jn-adm-marca{display:grid;place-items:center;width:46px;height:46px;border-radius:14px;font-size:22px;font-weight:800;color:#1b0a04;background:linear-gradient(145deg,#ffb59a,#ff5a36 55%,#b06aff);box-shadow:0 14px 30px -14px rgba(255,90,54,.9)}
		.jn-adm-cab h1{margin:0;font-size:20px;color:#fff}
		.jn-adm-cab p{margin:2px 0 0;color:#a99fae;font-size:12.5px}
		.jn-adm-cab__acciones{margin-left:auto;display:flex;gap:8px;flex-wrap:wrap}
		.jn-btn{display:inline-flex;align-items:center;gap:6px;border-radius:10px;padding:9px 15px;font-size:12.5px;font-weight:600;text-decoration:none;border:1px solid transparent;transition:filter .2s ease,transform .2s ease}
		.jn-btn:hover{transform:translateY(-1px)}
		.jn-btn--prin{background:linear-gradient(135deg,#ffb59a,#ff5a36 60%,#e2491f);color:#241007!important}
		.jn-btn--fant{background:rgba(255,255,255,.05);border-color:#2b2436;color:#f0e8f2!important}
		.jn-adm-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:26px}
		.jn-adm-stat{padding:14px 16px;border:1px solid #2b2436;border-radius:14px;background:linear-gradient(180deg,#15111d,#0d0b12)}
		.jn-adm-stat b{display:block;font-size:24px;line-height:1.1;color:#ffb09a;font-family:ui-monospace,Consolas,monospace}
		.jn-adm-stat span{font-size:11px;color:#a99fae}
		.jn-adm-stat--ver b{color:#c9c2ff}
		.jn-adm-tit{margin:0 0 12px!important;font-size:12px!important;letter-spacing:.18em;text-transform:uppercase;color:#a99fae!important;font-family:ui-monospace,Consolas,monospace}
		.jn-adm-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px;margin-bottom:28px}
		.jn-adm-card{display:grid;gap:2px;padding:15px 17px;border:1px solid #2b2436;border-radius:14px;background:linear-gradient(180deg,#14101b,#0d0b12);text-decoration:none;transition:transform .2s ease,border-color .2s ease,box-shadow .2s ease}
		.jn-adm-card:hover{transform:translateY(-3px);border-color:rgba(255,90,54,.55);box-shadow:0 18px 40px -28px rgba(255,90,54,.6)}
		.jn-adm-card__icono{color:#ff8a63;font-size:15px;line-height:1.2}
		.jn-adm-card b{color:#f7f1e8;font-size:13.5px}
		.jn-adm-card small{color:#8f8598;font-size:11px;line-height:1.4}
		.jn-adm-cols{display:grid;grid-template-columns:1.6fr 1fr;gap:16px;align-items:start}
		.jn-adm-caja{padding:18px 20px;border:1px solid #2b2436;border-radius:16px;background:linear-gradient(180deg,#12101a,#0b0910)}
		.jn-adm-tabla{width:100%;border-collapse:collapse;font-size:12.5px}
		.jn-adm-tabla th{text-align:left;font-family:ui-monospace,Consolas,monospace;font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:#8f8598;padding:6px 8px;border-bottom:1px solid #2b2436}
		.jn-adm-tabla td{padding:9px 8px;border-bottom:1px solid #201a29;color:#d9d0dd;vertical-align:middle}
		.jn-adm-tabla tr:last-child td{border-bottom:0}
		.jn-adm-tabla a{color:#ffb09a;text-decoration:none}
		.jn-adm-tabla__acc{text-align:right;white-space:nowrap}
		.jn-adm-tabla__acc a{margin-left:10px;font-family:ui-monospace,Consolas,monospace;font-size:11px}
		.jn-adm-chip{display:inline-block;font-family:ui-monospace,Consolas,monospace;font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:#9ff5df;border:1px solid rgba(51,214,192,.35);background:rgba(51,214,192,.1);border-radius:999px;padding:2px 8px}
		.jn-adm-video{width:100%;border-radius:12px;border:1px solid #2b2436;display:block;margin-bottom:10px;background:#08060d}
		.jn-adm-nota{color:#a99fae;font-size:11.5px;margin:0 0 8px}
		.jn-adm-nota a{color:#ff8a63;text-decoration:none}
		.jn-adm-lista{margin:0;padding-left:16px;color:#b7acb8;font-size:12px;line-height:1.6}
		.jn-adm-lista b{color:#fff}
		.jn-adm-vacio{color:#8f8598;font-size:12.5px}
		@media (max-width:960px){.jn-adm-cols{grid-template-columns:1fr}}
	</style>
	<?php
});
