<?php
/* Arnés temporal: genera una portada estática para revisar el tema en Chromium. */

define('ABSPATH', __DIR__ . '/');

function add_action(...$a) {}
function add_filter(...$a) {}
function get_stylesheet_directory_uri() { return '.'; }
function get_stylesheet_directory() { return __DIR__; }
function home_url($r = '') { return '#'; }
function admin_url($r = '') { return '#'; }
function esc_url($s) { return htmlspecialchars((string) $s, ENT_QUOTES); }
function esc_html($s) { return htmlspecialchars((string) $s, ENT_QUOTES); }
function date_i18n($f) { return date($f); }
function wp_count_posts($t = 'post') { $o = new stdClass(); $o->publish = 24; return $o; }
function wp_count_attachments() { $o = new stdClass(); $o->count = 18; return array($o); }
function wp_count_comments() { $o = new stdClass(); $o->approved = 6; $o->moderated = 1; $o->spam = 0; return $o; }

require __DIR__ . '/functions.php';

$tema = isset($argv[1]) && $argv[1] === 'oscuro' ? 'oscuro' : 'claro';
$salida = isset($argv[2]) ? $argv[2] : '.jn-preview.html';
$nav = $tema === 'oscuro' ? ' oscuro' : '';

$hero = '<div class="jn-hero">'
	. jn_bloque_hero_video()
	. '<span class="jn-badge">red educativa · v2.1</span>'
	. '<h1 class="wp-block-post-title jn-titulo">Jumper<span>NET</span></h1>'
	. '<p class="jn-sub">Documentación abierta de una red educativa de tres saltos: cómo viaja tu tráfico, qué ve cada nodo y por qué el camino importa.</p>'
	. '<div class="jn-stats">'
	. '<div><b>3</b><span>saltos por defecto</span></div>'
	. '<div><b>JENC</b><span>cifrado por capas</span></div>'
	. '<div><b>7:16</b><span>el documental</span></div>'
	. '</div></div>';

$html = '<!doctype html><html lang="es" data-jn-tema="' . $tema . '"><head><meta charset="utf-8">'
	. '<meta name="viewport" content="width=device-width,initial-scale=1">'
	. '<title>JumperNET · vista de prueba</title>'
	. '<link rel="stylesheet" href="style.css"></head><body class="home jn-navidad' . $nav . '">'
	. '<div class="wp-site-blocks"><header class="wp-block-group">'
	. '<div class="wp-block-group"><h1 class="wp-block-site-title"><a href="#">JumperNET</a></h1>'
	. '<nav class="wp-block-navigation"><ul><li><a href="#">Inicio</a></li><li><a href="#">Documentación</a></li><li><a href="#">Arquitectura</a></li><li><a href="#">Guía</a></li></ul></nav></div>'
	. '</header><main class="wp-block-group"><article><div class="wp-block-post-content-is-layout-flow wp-block-post-content">'
	. $hero
	. jn_bloque_pelicula()
	. jn_bloque_experiencia()
	. '</div></article></main>'
	. '<footer class="wp-block-group"><p>JumperNET · documentación abierta · hecho para aprender cómo viaja una conexión.</p></footer></div>'
	. '<div class="jn-fabs" role="group" aria-label="Controles del sitio">'
	. '<button type="button" class="jn-fab" data-jn-tema-btn aria-pressed="false" aria-label="Cambiar a modo oscuro"><span class="jn-fab__icono" aria-hidden="true">◐</span><span class="jn-fab__txt">oscuro</span></button>'
	. '<button type="button" class="jn-fab jn-fab--tour" data-jn-tour-ini aria-label="Iniciar el recorrido guiado"><span aria-hidden="true">→</span><span class="jn-fab__txt">recorrido</span></button></div>'
	. '<div class="jn-tour" data-jn-tour hidden aria-live="polite"><span class="jn-tour__paso" data-jn-tour-paso>1 / 6</span><p class="jn-tour__txt" data-jn-tour-txt>La portada completa, en un minuto.</p><div class="jn-tour__mandos"><button type="button" class="jn-btn jn-btn--mini" data-jn-tour-next>siguiente</button><button type="button" class="jn-btn jn-btn--fantasma jn-btn--mini" data-jn-tour-fin>salir</button></div></div>'
	. '<script>window.JN={video:"assets/el-viaje.mp4",portada:true,navidad:true,version:"2.1.0",corte:30};</script>'
	. '<script src="assets/jn-sitio.js"></script>'
	. '</body></html>';

file_put_contents(__DIR__ . '/' . $salida, $html);
echo "generado $salida (" . strlen($html) . " bytes)\n";
