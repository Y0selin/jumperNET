"use strict";

const navegador = typeof browser !== "undefined" ? browser : chrome;

const $ = (id) => document.getElementById(id);

/*
 * Estado REAL de la red (lo que no se debe confundir con el proxy):
 * hace login con las credenciales guardadas contra la API y pregunta /me.
 *   viva     -> la red esta encendida: el proxy del botón va a funcionar
 *   apagada  -> tus credenciales son válidas PERO no pulsaste el interruptor
 *               del panel web (la extension no enciende la red; solo ruta)
 *   rechazada-> email/clave no son los de tu cuenta de la web
 */
let ipEsperada = null;

/*
 * Prueba REAL tipo FoxyProxy: un fetch hecho DESDE ESTE POPUP sale por el
 * proxy del navegador (chrome.proxy / browser.proxy), asi que si la "IP que
 * ve internet" es la del circuito, tenéis la prueba directa de que ando
 * activa y funciona; y si es tu IP real, ahí está el problema para verlo.
 * Devolución: verde = coincide con la salida esperada del circuito.
 */
async function probarIp() {
  const caja = $("ipAhora");
  caja.textContent = "comprobando qué IP ve internet…";
  try {
    const r = await fetch(`https://api.ipify.org?cachebust=${Date.now()}`, { cache: "no-store" });
    const ip = (await r.text()).trim().slice(0, 64);
    if (ipEsperada && ip === ipEsperada) {
      caja.className = "estado-red mono viva";
      caja.textContent = `\u2713 IP que ve internet: ${ip} — es la de tu circuito, TODO funcionando`;
    } else {
      caja.className = "estado-red mono apagada";
      caja.textContent = ipEsperada
        ? `\u2717 IP que ve internet: ${ip} — esperada del circuito: ${ipEsperada} (el trafico NO esta saliendo por tu red)`
        : `IP que ve internet: ${ip} (tu IP directa — activa la red en la web y pulsa ACTIVAR aquí)`;
    }
  } catch (e0) {
    caja.className = "estado-red mono error";
    caja.textContent = "\u2717 el navegador no llegó a api.ipify.org — el proxy está activo PERO no contesta (¿red encendida? ¿credenciales correctas?)";
  }
}

async function comprobarRed() {
  const caja = $("estadoRed");
  const { configJumperNET } = await navegador.storage.local.get(["configJumperNET"]);
  const config = configJumperNET || {};
  if (!config.usuario || !config.clave) {
    caja.className = "estado-red mono";
    caja.textContent = "· sin credenciales todavía: escribe tu email y clave y pulsa ACTIVAR";
    return;
  }
  caja.textContent = "comprobando el estado de la red…";
  try {
    const r1 = await fetch(`https://${config.host}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: config.usuario, password: config.clave }),
    });
    if (!r1.ok) throw new Error(r1.status);
    const tok = (await r1.json()).token;
    const r2 = await fetch(`https://${config.host}/me`, { headers: { Authorization: `Bearer ${tok}` } });
    const yo = await r2.json();
  if (yo.activo) {
    caja.className = "estado-red mono viva";
    caja.textContent = `◉ red encendida · ${yo.circuito?.length || 3} saltos · exit: ${yo.nodo_exit || "—"}`;
    ipEsperada = yo.ip_salida || null;
    probarIp();
  } else {
    caja.className = "estado-red mono apagada";
    caja.textContent = "○ red APAGADA — pulsa un modo arriba para encenderla desde aquí (ya no hace falta ir a la web)";
  }
  marcaModo(yo.modo);
  } catch (e) {
    caja.className = "estado-red mono error";
    caja.textContent = "✕ credenciales rechazadas (o sin conexión con la API) — revisa email y clave";
  }
}

async function cargar() {
  const { configJumperNET, conflictoJumperNET } = await navegador.storage.local.get(["configJumperNET", "conflictoJumperNET"]);
  const config = configJumperNET || {};
  $("usuario").value = config.usuario || "";
  $("clave").value = config.clave || "";
  pintaConflicto(conflictoJumperNET || null);
  refrescarEstado();
}

/* banner del SECUESTRO del proxy: si otra extension (¿FoxyProxy?) escribió
 * chrome.proxy.settings después que esta, el tráfico sale directo y en el
 * popup se ve «mi IP real» con la red encendida. El vigía del fondo re-afirma
 * la ours cada minuto; aquí te decimos EL QUIÉN con el detalle del ajuste. */
function pintaConflicto(txt) {
  const caja = $("conflicto");
  if (!txt) { caja.className = "conflicto mono oculto"; caja.textContent = ""; return; }
  caja.className = "conflicto mono";
  caja.innerHTML = null;
  caja.append(
    "\u26a0 Otra extensi\u00f3n proxy est\u00e1 pisando el ajuste del navegador (\u00bFTienes FoxyProxy?). ",
    Object.assign(document.createElement("b"), { textContent: "Desinst\u00e1lala" }),
    " (chrome://extensions) o ponla con opci\u00f3n \u00abde proxy desactivada\u00bb. JumperNET re-afirma la suya cada minuto.",
  );
}

try {
  navegador.storage.onChanged.addListener((cambios, area) => {
    if (area === "local" && cambios.conflictoJumperNET) pintaConflicto(cambios.conflictoJumperNET.newValue || null);
  });
} catch { /* navegadores sin onChanged en el popup: la carga inicial vale */ }

async function refrescarEstado() {
  const { configJumperNET } = await navegador.storage.local.get(["configJumperNET"]);
  const config = configJumperNET || {};
  const viva = !!(config.activo && config.usuario && config.clave);
  $("punto").className = "punto" + (viva ? " viva" : "");
  $("estadoTxt").textContent = viva
    ? `— activo via ${config.host}:${config.puerto}`
    : "— apagado";
  $("encender").textContent = viva ? "Reaplicar" : "Activar";
}

/* ── encender/cambiar la red DESDE la extensión ──
 * POST /connect (o /rotate si ya está encendida) con el modo elegido.
 * La IP esperada sale de /me (el backend calcula la del EXIT REAL: la de la
 * casa del peer externo, no la del VPS). */

async function tokenCon(cred) {
  const r = await fetch(`https://${cred.host}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: cred.usuario, password: cred.clave }),
  });
  if (!r.ok) throw new Error("login " + r.status);
  return (await r.json()).token;
}

function marcaModo(modo) {
  $("modoTodos").classList.toggle("primario", modo === "todos");
  $("modoExternos").classList.toggle("primario", modo === "externos");
}

let cambiandoRed = false;
async function aplicarModo(modo) {
  if (cambiandoRed) return;
  cambiandoRed = true;
  const caja = $("estadoRed");
  const anterior = caja.textContent;
  try {
    const { configJumperNET } = await navegador.storage.local.get(["configJumperNET"]);
    const cred = configJumperNET || {};
    if (!cred.usuario || !cred.clave) {
      caja.className = "estado-red mono error";
      caja.textContent = "✕ escribe tu email y clave y pulsa ACTIVAR antes";
      return;
    }
    marcaModo(modo);
    caja.className = "estado-red mono";
    caja.textContent = modo === "externos" ? "… enciendo/actualizo el circuito SOLO EXTERNO…" : "… enciendo/actualizo el circuito…";
    const tok = await tokenCon(cred);
    const rMe = await fetch(`https://${cred.host}/me`, { headers: { Authorization: `Bearer ${tok}` } });
    const yo = await rMe.json();
    if (yo.activo && yo.modo === modo) {
      // nada que cambiar: solo repintamos y probamos
      await guardar({ activo: true });
      refrescarEstado();
      comprobarRed();
      return;
    }
    // rotate respeta el modo PREVIO (y los planes free tienen cooldown de
    // refresco), así que un cambio real de modo va por disconnect+connect,
    // que no lleva cooldown. Se conservan el nº de saltos ya elegido.
    const saltos = yo.circuito?.length || 3;
    let ruta = `https://${cred.host}/connect`;
    let cuerpo = { modo, saltos };
    if (yo.activo) {
      const rOff = await fetch(`https://${cred.host}/disconnect`, { method: "POST", headers: { Authorization: `Bearer ${tok}` } });
      if (!rOff.ok) throw new Error("no se pudo apagar antes del cambio (HTTP " + rOff.status + ")");
    }
    const r2 = await fetch(ruta, {
      method: "POST",
      headers: { "Authorization": `Bearer ${tok}`, "Content-Type": "application/json" },
      body: JSON.stringify(cuerpo),
    });
    if (!r2.ok) {
      const e = await r2.json().catch(() => ({}));
      throw new Error((e && e.detail) || ("HTTP " + r2.status));
    }
    await guardar({ activo: true });
    refrescarEstado();
    comprobarRed();   // repinta estado + IP esperada + prueba real
  } catch (e) {
    caja.className = "estado-red mono error";
    caja.textContent = "✕ " + String(e.message || e).slice(0, 120);
    marcaModo(null);
  } finally {
    cambiandoRed = false;
    if (caja.className.includes("error")) { /* el mensaje de error queda visible */ }
  }
}

async function guardar(extra) {
  const config = {
    host: "jumpernet.duckdns.org",
    puerto: 1081,
    usuario: $("usuario").value.trim(),
    clave: $("clave").value,
    activo: false,
    ...(extra || {}),
  };
  await navegador.storage.local.set({ configJumperNET: config });
  return config;
}

$("encender").addEventListener("click", async () => {
  await guardar({ activo: true });
  refrescarEstado();
});

$("apagar").addEventListener("click", async () => {
  await guardar({ activo: false });
  refrescarEstado();
});

$("olvidar").addEventListener("click", async () => {
  $("usuario").value = "";
  $("clave").value = "";
  await guardar({ activo: false });
  refrescarEstado();
});

cargar();
comprobarRed();

// la IP que ve internet se mide al abrir el popup y con el boton del refresco
probarIp();
$("probarIp").addEventListener("click", probarIp);

$("modoTodos").addEventListener("click", () => aplicarModo("todos"));
$("modoExternos").addEventListener("click", () => aplicarModo("externos"));
